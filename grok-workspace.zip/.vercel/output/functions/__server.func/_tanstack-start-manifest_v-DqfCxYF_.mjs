//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DqfCxYF_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DrL_i37e.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DrL_i37e.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DuqwF6ft.js"]
	}
} });
//#endregion
export { tsrStartManifest };
