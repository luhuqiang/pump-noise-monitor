import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, c as MicOff, d as CircleHelp, f as Check, i as RotateCcw, l as Gauge, n as Unplug, o as Pause, p as AudioLines, r as TriangleAlert, s as Mic, t as Waves, u as Download } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CRjGgp1-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var THIRD_OCTAVE = [
	{
		fc: 25,
		label: "25",
		tick: false
	},
	{
		fc: 31.5,
		label: "31.5",
		tick: true
	},
	{
		fc: 40,
		label: "40",
		tick: false
	},
	{
		fc: 50,
		label: "50",
		tick: false
	},
	{
		fc: 63,
		label: "63",
		tick: false
	},
	{
		fc: 80,
		label: "80",
		tick: false
	},
	{
		fc: 100,
		label: "100",
		tick: false
	},
	{
		fc: 125,
		label: "125",
		tick: true
	},
	{
		fc: 160,
		label: "160",
		tick: false
	},
	{
		fc: 200,
		label: "200",
		tick: false
	},
	{
		fc: 250,
		label: "250",
		tick: false
	},
	{
		fc: 315,
		label: "315",
		tick: false
	},
	{
		fc: 400,
		label: "400",
		tick: false
	},
	{
		fc: 500,
		label: "500",
		tick: true
	},
	{
		fc: 630,
		label: "630",
		tick: false
	},
	{
		fc: 800,
		label: "800",
		tick: false
	},
	{
		fc: 1e3,
		label: "1k",
		tick: true
	},
	{
		fc: 1250,
		label: "1.25k",
		tick: false
	},
	{
		fc: 1600,
		label: "1.6k",
		tick: false
	},
	{
		fc: 2e3,
		label: "2k",
		tick: true
	},
	{
		fc: 2500,
		label: "2.5k",
		tick: false
	},
	{
		fc: 3150,
		label: "3.15k",
		tick: false
	},
	{
		fc: 4e3,
		label: "4k",
		tick: false
	},
	{
		fc: 5e3,
		label: "5k",
		tick: false
	},
	{
		fc: 6300,
		label: "6.3k",
		tick: false
	},
	{
		fc: 8e3,
		label: "8k",
		tick: true
	},
	{
		fc: 1e4,
		label: "10k",
		tick: false
	},
	{
		fc: 12500,
		label: "12.5k",
		tick: false
	},
	{
		fc: 16e3,
		label: "16k",
		tick: false
	},
	{
		fc: 2e4,
		label: "20k",
		tick: false
	}
];
var HALF = Math.pow(2, 1 / 6);
function synthesizeOctave(db, sampleRate, fftSize) {
	const out = new Float32Array(THIRD_OCTAVE.length);
	const n = db.length;
	for (let b = 0; b < THIRD_OCTAVE.length; b++) {
		const fc = THIRD_OCTAVE[b].fc;
		const f1 = fc / HALF;
		const f2 = fc * HALF;
		let i1 = Math.max(1, Math.ceil(f1 * fftSize / sampleRate));
		let i2 = Math.min(n - 1, Math.floor(f2 * fftSize / sampleRate));
		if (i2 < i1) {
			const center = Math.round(fc * fftSize / sampleRate);
			i1 = Math.max(1, Math.min(n - 1, center));
			i2 = i1;
		}
		let p = 0;
		for (let i = i1; i <= i2; i++) {
			const v = db[i] ?? -140;
			p += Math.pow(10, (Number.isFinite(v) ? v : -140) / 10);
		}
		out[b] = p > 0 ? 10 * Math.log10(p) : -140;
	}
	return out;
}
function evidence(f) {
	return [
		`平坦度 ${f.flatness.toFixed(2)}`,
		`高频比 ${f.hfRatio.toFixed(2)}`,
		`峭度 ${f.kurtosis.toFixed(1)}`,
		`波峰因数 ${f.crest.toFixed(2)}`,
		`1×/叶片 ${f.oneXRatio.toFixed(2)}`,
		`半阶次 ${f.halfRatio.toFixed(2)}`
	];
}
function diagnose(f) {
	const ev = evidence(f);
	if (!Number.isFinite(f.level) || f.level < 40) return {
		id: "silence",
		title: "信号太弱",
		summary: "电平不够，故障线索没有意义。靠近泵体，或先打开演示声源确认仪表在工作。",
		confidence: "低",
		evidence: ev
	};
	if (Math.abs(f.dominantHz - 1e3) < 20 && f.flatness < .25 && f.crest < 2.2 && f.kurtosis < 3.5) return {
		id: "ref",
		title: "1 kHz 正弦",
		summary: "几乎只有一根谱线。A、C、Z 三种计权在 1 kHz 上应当重合，用来核对这台仪表，不是泵的声音。",
		confidence: "高",
		evidence: ev
	};
	if (f.kurtosis >= 6 && f.crest >= 2.8) return {
		id: "bearing",
		title: "疑似轴承冲击",
		summary: "峭度和波峰因数一起升高，声压里有重复冲击，不只是平稳的叶片音。轴承损伤会这样，防护罩碰磨也会。对照润滑和振动峭度再下判断。",
		confidence: f.kurtosis >= 10 ? "高" : "中",
		evidence: ev
	};
	if (f.hfRatio >= .9 && f.flatness >= .22) return {
		id: "cavitation",
		title: "疑似汽蚀",
		summary: "2–8 kHz 相对低频抬起来了，频谱更像宽带噪声，而不是清楚的叶片音。现场常见于汽蚀、进口不畅或强湍流。核对流量、进口压力和安装汽蚀余量。",
		confidence: f.hfRatio >= 2 && f.flatness >= .12 ? "高" : "中",
		evidence: ev
	};
	if (f.halfRatio >= .45 && f.harmonicCount >= 4) return {
		id: "looseness",
		title: "疑似机械松动",
		summary: "0.5×、1.5× 这类半阶次明显，整数谐波也铺得很开。地脚、轴承座或联轴器松动时常是这种空气声。",
		confidence: f.halfRatio >= .8 ? "高" : "中",
		evidence: ev
	};
	if (f.oneXRatio >= 2.4 && f.hfRatio < 1.2 && f.flatness < .2) return {
		id: "imbalance",
		title: "疑似叶轮不平衡",
		summary: "1 倍转频明显高于叶片通过频率。空气声里的转频突出，要和不平衡、偏心或对中不良一起看，最好对照振动里的 1×。",
		confidence: f.oneXRatio >= 4 ? "高" : "中",
		evidence: ev
	};
	if (f.bpfRatio >= 1.3 && f.hfRatio < .7 && f.kurtosis < 6 && f.halfRatio < .35) return {
		id: "healthy",
		title: "运转平稳",
		summary: "能量集中在叶片通过频率附近，转频不强，高频本底和峭度都低。这组形态接近平稳运行的离心泵。",
		confidence: f.bpfRatio >= 2 ? "高" : "中",
		evidence: ev
	};
	return {
		id: "mixed",
		title: "特征不明显",
		summary: "几项指标没有同时指向同一种典型故障。换一个听音位置，确认转速和叶片数，或和振动测量对照。",
		confidence: "低",
		evidence: ev
	};
}
function dbToPower(db) {
	if (!Number.isFinite(db)) return 0;
	return Math.pow(10, Math.max(-140, db) / 10);
}
function powerAround(db, sampleRate, fftSize, freq) {
	if (freq < 12) return 0;
	const center = Math.round(freq * fftSize / sampleRate);
	const half = Math.max(1, Math.round(center * .045));
	let p = 0;
	for (let i = center - half; i <= center + half; i++) {
		if (i < 1 || i >= db.length) continue;
		p += dbToPower(db[i] ?? -140);
	}
	return p;
}
function powerBetween(db, sampleRate, fftSize, f1, f2) {
	const i1 = Math.max(1, Math.floor(f1 * fftSize / sampleRate));
	const i2 = Math.min(db.length - 1, Math.ceil(f2 * fftSize / sampleRate));
	let p = 0;
	for (let i = i1; i <= i2; i++) p += dbToPower(db[i] ?? -140);
	return p;
}
function spectralFeatures(db, sampleRate, fftSize, rpm, blades) {
	const n = db.length;
	let maxI = 2;
	let maxV = -Infinity;
	const minBin = Math.max(2, Math.floor(20 * fftSize / sampleRate));
	const maxBin = Math.min(n - 2, Math.floor(5e3 * fftSize / sampleRate));
	for (let i = minBin; i <= maxBin; i++) {
		const v = db[i] ?? -140;
		if (v > maxV) {
			maxV = v;
			maxI = i;
		}
	}
	const a = db[maxI - 1] ?? maxV;
	const b = db[maxI] ?? maxV;
	const c = db[maxI + 1] ?? maxV;
	const denom = a - 2 * b + c;
	const delta = denom === 0 ? 0 : .5 * (a - c) / denom;
	const dominantHz = Math.max(0, (maxI + delta) * sampleRate / fftSize);
	let logSum = 0;
	let sum = 0;
	let count = 0;
	const iLo = Math.max(1, Math.floor(200 * fftSize / sampleRate));
	const iHi = Math.min(n - 1, Math.floor(8e3 * fftSize / sampleRate));
	for (let i = iLo; i <= iHi; i++) {
		const mag = Math.pow(10, Math.max(-140, db[i] ?? -140) / 20);
		sum += mag;
		logSum += Math.log(mag + 1e-16);
		count++;
	}
	const flatness = count > 0 && sum > 0 ? Math.exp(logSum / count) / (sum / count) : 0;
	const hf = powerBetween(db, sampleRate, fftSize, 2e3, 8e3);
	const lf = powerBetween(db, sampleRate, fftSize, 40, 500);
	const hfRatio = hf / Math.max(lf, 1e-18);
	const f0 = rpm > 0 ? rpm / 60 : 0;
	let oneXRatio = 0;
	let bpfRatio = 0;
	let halfRatio = 0;
	let harmonicCount = 0;
	if (f0 >= 15) {
		const p1 = powerAround(db, sampleRate, fftSize, f0);
		const bpf = powerAround(db, sampleRate, fftSize, f0 * Math.max(2, blades));
		oneXRatio = p1 / Math.max(bpf, 1e-18);
		bpfRatio = bpf / Math.max(p1, 1e-18);
		let halfP = 0;
		let intP = 0;
		let loudest = 0;
		const harms = [];
		for (let h = 1; h <= 10; h++) {
			const p = powerAround(db, sampleRate, fftSize, f0 * h);
			harms.push(p);
			if (p > loudest) loudest = p;
			if (h <= 4) intP += p;
		}
		halfP += powerAround(db, sampleRate, fftSize, f0 * .5);
		halfP += powerAround(db, sampleRate, fftSize, f0 * 1.5);
		halfP += powerAround(db, sampleRate, fftSize, f0 * 2.5);
		halfP += powerAround(db, sampleRate, fftSize, f0 * 3.5);
		halfRatio = halfP / Math.max(intP, 1e-18);
		const gate = loudest * Math.pow(10, -12 / 10);
		harmonicCount = harms.filter((p) => p >= gate && p > 0).length;
		if (intP < 1e-12) {
			oneXRatio = 0;
			bpfRatio = 0;
			halfRatio = 0;
		}
	}
	return {
		dominantHz,
		flatness,
		hfRatio: Math.min(hfRatio, 99),
		oneXRatio: Math.min(oneXRatio, 99),
		bpfRatio: Math.min(bpfRatio, 99),
		halfRatio: Math.min(halfRatio, 99),
		harmonicCount
	};
}
/**
* Pump synthesizer shared verbatim with an AudioWorklet.
* Keep this string free of closures, template placeholders, and TypeScript.
*/
var DSP_SOURCE = `
function createPumpState(mode, rpm, blades) {
  var twopi = 6.283185307179586;
  var s = {
    mode: mode | 0,
    rpm: rpm,
    blades: blades | 0,
    phase: new Float32Array(17),
    fphase: new Float32Array(4),
    seed: ((mode * 10007 + (rpm | 0) * 13 + (blades | 0) * 99) | 0) || 123456789,
    lp: 0,
    ring: 0,
    ringPhase: 0,
    n: 0,
  };
  var h, x;
  for (h = 0; h < 17; h++) {
    x = s.seed | 0;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    s.seed = x || 123456789;
    s.phase[h] = ((x >>> 0) / 4294967296) * twopi;
  }
  for (h = 0; h < 4; h++) {
    x = s.seed | 0;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    s.seed = x || 123456789;
    s.fphase[h] = ((x >>> 0) / 4294967296) * twopi;
  }
  return s;
}

function pumpSample(s, sr) {
  var f0 = s.rpm / 60;
  var dt = 1 / sr;
  var twopi = 6.283185307179586;
  var y = 0;
  var blades = s.blades | 0;
  var mode = s.mode | 0;
  var h, amp;

  for (h = 1; h <= 16; h++) {
    amp = 0;
    if (mode === 0) {
      if (h === 1) amp = 0.12;
      else if (h === 2) amp = 0.045;
      else if (h === 3) amp = 0.02;
      else if (h === blades) amp = 0.85;
      else if (h === blades * 2 && h <= 16) amp = 0.28;
    } else if (mode === 1) {
      if (h === 1) amp = 0.1;
      else if (h === blades) amp = 0.32;
      else if (h === blades * 2 && h <= 16) amp = 0.08;
    } else if (mode === 2) {
      if (h === 1) amp = 1;
      else if (h === 2) amp = 0.22;
      else if (h === 3) amp = 0.08;
      else if (h === blades) amp = 0.15;
    } else if (mode === 3) {
      amp = 0.48 / Math.sqrt(h);
    } else if (mode === 4) {
      if (h === 1) amp = 0.14;
      else if (h === 2) amp = 0.05;
      else if (h === blades) amp = 0.42;
    }
    if (amp > 0) {
      s.phase[h] += twopi * f0 * h * dt;
      if (s.phase[h] > twopi) s.phase[h] -= twopi;
      y += amp * Math.sin(s.phase[h]);
    }
  }

  if (mode === 3) {
    var fr = [0.5, 1.5, 2.5, 3.5];
    var fa = [0.72, 0.48, 0.32, 0.18];
    for (h = 0; h < 4; h++) {
      s.fphase[h] += twopi * f0 * fr[h] * dt;
      if (s.fphase[h] > twopi) s.fphase[h] -= twopi;
      y += fa[h] * Math.sin(s.fphase[h]);
    }
  }

  var x = s.seed | 0;
  x ^= x << 13;
  x ^= x >>> 17;
  x ^= x << 5;
  s.seed = x;
  var white = ((x >>> 0) / 4294967296) * 2 - 1;
  var alpha = mode === 1 ? 0.18 : 0.02;
  s.lp += alpha * (white - s.lp);
  var hp = white - s.lp;
  var nAmp = 0.06;
  var nSig = s.lp;
  if (mode === 1) {
    nAmp = 2.2;
    nSig = hp;
  } else if (mode === 3) {
    nAmp = 0.16;
    nSig = s.lp;
  } else if (mode === 4) {
    nAmp = 0.05;
    nSig = s.lp;
  }
  if (mode === 1) {
    var mod = 0.72 + 0.28 * Math.sin(twopi * 19 * s.n * dt);
    y += nAmp * nSig * mod;
  } else {
    y += nAmp * nSig;
  }

  if (mode === 4) {
    var rate = f0 * 3.07;
    var period = Math.max(8, Math.round(sr / rate));
    if (s.n % period === 0) s.ring = 1;
    s.ring *= Math.exp(-dt / 0.00065);
    s.ringPhase += twopi * 4200 * dt;
    if (s.ringPhase > twopi) s.ringPhase -= twopi;
    y += s.ring * Math.sin(s.ringPhase) * 11;
  }

  s.n++;
  if (y !== y) return 0;
  return y;
}
`;
var WORKLET_SOURCE = `${DSP_SOURCE}
class PumpSynth extends AudioWorkletProcessor {
  constructor() {
    super();
    this.state = createPumpState(0, 2950, 6);
    this.port.onmessage = function (ev) {
      var d = ev.data || {};
      if (d.type === "set") {
        this.state = createPumpState(d.mode, d.rpm, d.blades);
      }
    }.bind(this);
  }
  process(inputs, outputs) {
    var out = outputs[0] && outputs[0][0];
    if (!out) return true;
    var i;
    for (i = 0; i < out.length; i++) out[i] = pumpSample(this.state, sampleRate);
    return true;
  }
}

class PumpMeter extends AudioWorkletProcessor {
  constructor() {
    super();
    this.z2 = 0;
    this.z4 = 0;
    this.zn = 0;
    this.a2 = 0;
    this.c2 = 0;
    this.zpk = 0;
    this.cpk = 0;
    this.hop = 0;
  }
  process(inputs, outputs) {
    var out = outputs[0] && outputs[0][0];
    if (out) out.fill(0);
    var z = inputs[0] && inputs[0][0];
    var a = inputs[1] && inputs[1][0];
    var c = inputs[2] && inputs[2][0];
    var n = z ? z.length : a ? a.length : c ? c.length : 0;
    if (!n) return true;
    var i, x, x2, ax;
    for (i = 0; i < n; i++) {
      if (z) {
        x = z[i];
        x2 = x * x;
        this.z2 += x2;
        this.z4 += x2 * x2;
        ax = x < 0 ? -x : x;
        if (ax > this.zpk) this.zpk = ax;
        this.zn++;
      }
      if (a) this.a2 += a[i] * a[i];
      if (c) {
        x = c[i];
        this.c2 += x * x;
        ax = x < 0 ? -x : x;
        if (ax > this.cpk) this.cpk = ax;
      }
    }
    this.hop += n;
    if (this.hop >= sampleRate * 0.05) {
      var zn = this.zn > 0 ? this.zn : 1;
      this.port.postMessage({
        dt: this.hop / sampleRate,
        zMs: this.z2 / zn,
        zK: this.z4 / zn,
        zPk: this.zpk,
        aMs: this.a2 / zn,
        cMs: this.c2 / zn,
        cPk: this.cpk,
      });
      this.z2 = 0;
      this.z4 = 0;
      this.a2 = 0;
      this.c2 = 0;
      this.zn = 0;
      this.zpk = 0;
      this.cpk = 0;
      this.hop = 0;
    }
    return true;
  }
}

registerProcessor("pump-synth", PumpSynth);
registerProcessor("pump-meter", PumpMeter);
`;
var fns = null;
function getPumpFns() {
	if (!fns) fns = new Function(`${DSP_SOURCE}; return { createPumpState, pumpSample };`)();
	return fns;
}
var gainCache = /* @__PURE__ */ new Map();
/** Linear gain that places the scenario at targetDb when 0 dBFS equals splRef. */
function scenarioGain(mode, rpm, blades, sampleRate, targetDb, splRef) {
	const key = `${mode}|${rpm}|${blades}|${sampleRate}|${targetDb}|${splRef}`;
	const hit = gainCache.get(key);
	if (hit !== void 0) return hit;
	const { createPumpState, pumpSample } = getPumpFns();
	const state = createPumpState(mode, rpm, blades);
	const n = Math.min(sampleRate, 48e3);
	let sum = 0;
	for (let i = 0; i < n; i++) {
		const y = pumpSample(state, sampleRate);
		sum += y * y;
	}
	const rms = Math.sqrt(sum / n) || 1e-9;
	const gain = Math.pow(10, (targetDb - splRef) / 20) / rms;
	gainCache.set(key, gain);
	return gain;
}
var SCENARIOS = [
	{
		id: "healthy",
		mode: 0,
		name: "健康离心泵",
		rpm: 2950,
		blades: 6,
		targetDb: 76,
		blurb: "叶片通过频率清楚，高频本底低。名义声级按 0 dBFS = 120 dB 制作。"
	},
	{
		id: "cavitation",
		mode: 1,
		name: "汽蚀",
		rpm: 2950,
		blades: 6,
		targetDb: 97,
		blurb: "同样的叶片音被 2 kHz 以上的宽带噪声盖住，声级也抬高。"
	},
	{
		id: "imbalance",
		mode: 2,
		name: "叶轮不平衡",
		rpm: 2950,
		blades: 6,
		targetDb: 83,
		blurb: "1 倍转频被加重。可改转速，看这根谱线跟着动。"
	},
	{
		id: "looseness",
		mode: 3,
		name: "机械松动",
		rpm: 2950,
		blades: 6,
		targetDb: 88,
		blurb: "半阶次和一长串转频谐波。名义声级会越过警告线。"
	},
	{
		id: "bearing",
		mode: 4,
		name: "轴承冲击",
		rpm: 2950,
		blades: 6,
		targetDb: 80,
		blurb: "重复冲击把峭度和波峰因数拉高，总声级不一定很大。"
	}
];
function getScenario(id) {
	return SCENARIOS.find((s) => s.id === id) ?? SCENARIOS[0];
}
var F1 = 20.598997;
var F2 = 107.65265;
var F3 = 737.86223;
var F4 = 12194.217;
function ra(f) {
	const f2 = f * f;
	const c1 = F4 * F4;
	return c1 * f2 * f2 / ((f2 + F1 * F1) * Math.sqrt((f2 + F2 * F2) * (f2 + F3 * F3)) * (f2 + c1));
}
function rc(f) {
	const f2 = f * f;
	const c1 = F4 * F4;
	return c1 * f2 / ((f2 + F1 * F1) * (f2 + c1));
}
var RA_1K = ra(1e3);
var RC_1K = rc(1e3);
function aWeightDb(f) {
	if (f < 1) return -80;
	return 20 * Math.log10(ra(f) / RA_1K);
}
function cWeightDb(f) {
	if (f < 1) return -80;
	return 20 * Math.log10(rc(f) / RC_1K);
}
function weightDb(kind, f) {
	if (kind === "A") return aWeightDb(f);
	if (kind === "C") return cWeightDb(f);
	return 0;
}
function bilinear(b0, b1, b2, a0, a1, a2, fs) {
	const k = 2 * fs;
	const k2 = k * k;
	const nb0 = b0 * k2 + b1 * k + b2;
	const nb1 = 2 * (b2 - b0 * k2);
	const nb2 = b0 * k2 - b1 * k + b2;
	const na0 = a0 * k2 + a1 * k + a2;
	const na1 = 2 * (a2 - a0 * k2);
	const na2 = a0 * k2 - a1 * k + a2;
	const inv = 1 / na0;
	return {
		ff: [
			nb0 * inv,
			nb1 * inv,
			nb2 * inv
		],
		fb: [
			1,
			na1 * inv,
			na2 * inv
		]
	};
}
function biquadMag(biq, freq, fs) {
	const w = 2 * Math.PI * freq / fs;
	const c1 = Math.cos(w);
	const s1 = Math.sin(w);
	const c2 = Math.cos(2 * w);
	const s2 = Math.sin(2 * w);
	const b0 = biq.ff[0] ?? 0;
	const b1 = biq.ff[1] ?? 0;
	const b2 = biq.ff[2] ?? 0;
	const a0 = biq.fb[0] ?? 1;
	const a1 = biq.fb[1] ?? 0;
	const a2 = biq.fb[2] ?? 0;
	const nr = b0 + b1 * c1 + b2 * c2;
	const ni = -(b1 * s1 + b2 * s2);
	const dr = a0 + a1 * c1 + a2 * c2;
	const di = -(a1 * s1 + a2 * s2);
	return Math.hypot(nr, ni) / Math.hypot(dr, di);
}
function normalizeCascade(sections, fs) {
	for (const s of sections) {
		const g = 1 / (biquadMag(s, 1e3, fs) || 1);
		s.ff[0] = (s.ff[0] ?? 0) * g;
		s.ff[1] = (s.ff[1] ?? 0) * g;
		s.ff[2] = (s.ff[2] ?? 0) * g;
	}
}
function designAWeighting(fs) {
	const w1 = 2 * Math.PI * F1;
	const w2 = 2 * Math.PI * F2;
	const w3 = 2 * Math.PI * F3;
	const w4 = 2 * Math.PI * F4;
	const sections = [
		bilinear(1, 0, 0, 1, 2 * w1, w1 * w1, fs),
		bilinear(1, 0, 0, 1, w2 + w3, w2 * w3, fs),
		bilinear(0, 0, 1, 1, 2 * w4, w4 * w4, fs)
	];
	normalizeCascade(sections, fs);
	return sections;
}
function designCWeighting(fs) {
	const w1 = 2 * Math.PI * F1;
	const w4 = 2 * Math.PI * F4;
	const sections = [bilinear(1, 0, 0, 1, 2 * w1, w1 * w1, fs), bilinear(0, 0, 1, 1, 2 * w4, w4 * w4, fs)];
	normalizeCascade(sections, fs);
	return sections;
}
var KEY = "pump-acoustic-settings-v1";
var DEFAULTS = {
	source: "demo",
	scenario: "healthy",
	rpm: 2950,
	blades: 6,
	weighting: "A",
	splAt0: 120,
	warn: 85,
	danger: 95,
	peakHold: true,
	monitor: true,
	alarms: []
};
function persist(data) {
	try {
		localStorage.setItem(KEY, JSON.stringify(data));
	} catch {}
}
function snapshot(s) {
	return {
		source: s.source,
		scenario: s.scenario,
		rpm: s.rpm,
		blades: s.blades,
		weighting: s.weighting,
		splAt0: s.splAt0,
		warn: s.warn,
		danger: s.danger,
		peakHold: s.peakHold,
		monitor: s.monitor,
		alarms: s.alarms
	};
}
var useSettings = create((set, get) => ({
	...DEFAULTS,
	loaded: false,
	load: () => {
		if (get().loaded) return;
		let next = DEFAULTS;
		try {
			const raw = localStorage.getItem(KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				next = {
					...DEFAULTS,
					...parsed
				};
				if (!Array.isArray(next.alarms)) next.alarms = [];
			}
		} catch {
			next = DEFAULTS;
		}
		set({
			...next,
			loaded: true
		});
	},
	update: (partial) => {
		set(partial);
		if (get().loaded) persist(snapshot(get()));
	},
	selectScenario: (id) => {
		const scenario = getScenario(id);
		set({
			source: "demo",
			scenario: id,
			rpm: scenario.rpm,
			blades: scenario.blades
		});
		if (get().loaded) persist(snapshot(get()));
	},
	pushAlarm: (alarm) => {
		set({ alarms: [alarm, ...get().alarms].slice(0, 12) });
		if (get().loaded) persist(snapshot(get()));
	},
	clearAlarms: () => {
		set({ alarms: [] });
		if (get().loaded) persist(snapshot(get()));
	}
}));
var EMPTY = {
	running: false,
	frozen: false,
	source: "demo",
	weighting: "A",
	fast: NaN,
	slow: NaN,
	leq1: NaN,
	leq10: NaN,
	cpeak: NaN,
	lmax: NaN,
	crest: NaN,
	kurtosis: NaN,
	dominantHz: 0,
	flatness: NaN,
	hfRatio: NaN,
	splAt0: 120,
	clipped: false,
	error: null,
	diagnosis: null,
	meter: "idle"
};
function dbOf(ms, splAt0) {
	if (!(ms > 0)) return splAt0 - 120;
	return 10 * Math.log10(ms) + splAt0;
}
function smooth(prev, next, dt, tau) {
	return prev + (1 - Math.exp(-dt / tau)) * (next - prev);
}
var Ring = class {
	max;
	buf = [];
	sum = 0;
	constructor(max) {
		this.max = max;
	}
	clear() {
		this.buf = [];
		this.sum = 0;
	}
	push(ms) {
		this.buf.push(ms);
		this.sum += ms;
		if (this.buf.length > this.max) this.sum -= this.buf.shift() ?? 0;
	}
	db(splAt0) {
		if (!this.buf.length || this.sum <= 0) return NaN;
		return 10 * Math.log10(this.sum / this.buf.length) + splAt0;
	}
};
var Engine = class {
	readout = { ...EMPTY };
	displayDb = /* @__PURE__ */ new Float32Array(0);
	peakDb = /* @__PURE__ */ new Float32Array(0);
	octaveDb = /* @__PURE__ */ new Float32Array(0);
	waterfall = /* @__PURE__ */ new Float32Array(6e4);
	waterfallCols = 400;
	waterfallRows = 150;
	waterfallHead = 0;
	trend = /* @__PURE__ */ new Float32Array(600);
	trendHead = 0;
	trendCount = 0;
	fftSize = 8192;
	sampleRate = 48e3;
	ctx = null;
	master = null;
	calGain = null;
	oscGain = null;
	micGain = null;
	monitor = null;
	analyser = null;
	analyserA = null;
	analyserC = null;
	synth = null;
	meter = null;
	osc = null;
	micNode = null;
	micStream = null;
	freqDb = /* @__PURE__ */ new Float32Array(0);
	weighted = /* @__PURE__ */ new Float32Array(0);
	timeZ = /* @__PURE__ */ new Float32Array(0);
	timeA = /* @__PURE__ */ new Float32Array(0);
	timeC = /* @__PURE__ */ new Float32Array(0);
	rowTmp = /* @__PURE__ */ new Float32Array(400);
	raf = 0;
	starting = null;
	sawMeter = false;
	seeded = false;
	zFast = 0;
	aFast = 0;
	cFast = 0;
	zSlow = 0;
	aSlow = 0;
	cSlow = 0;
	leqFast = new Ring(20);
	leqSlow = new Ring(200);
	trendWrite = 0;
	leqAcc = 0;
	lastFallback = 0;
	lastRow = 0;
	lastFeat = 0;
	lastShift = 0;
	weightKey = "";
	weights = /* @__PURE__ */ new Float32Array(0);
	synthKey = "";
	routeKey = "";
	micAsk = 0;
	frozen = false;
	running = false;
	constructor() {
		this.waterfall.fill(-200);
		this.octaveDb = /* @__PURE__ */ new Float32Array(31);
	}
	dispose() {
		this.running = false;
		this.frozen = false;
		cancelAnimationFrame(this.raf);
		this.raf = 0;
		this.releaseMic();
		this.osc?.stop();
		this.ctx?.close();
		this.ctx = null;
		this.readout = { ...EMPTY };
	}
	async start() {
		if (this.running) {
			await this.sync();
			return;
		}
		await this.ensure();
		this.resetIntegrators();
		this.running = true;
		this.frozen = false;
		this.readout.running = true;
		this.readout.frozen = false;
		this.readout.error = null;
		await this.sync();
	}
	stop() {
		this.running = false;
		this.frozen = false;
		this.readout.running = false;
		this.readout.frozen = false;
		this.zeroGains();
		this.releaseMic();
	}
	toggleFreeze() {
		if (!this.running) return;
		this.frozen = !this.frozen;
		this.readout.frozen = this.frozen;
	}
	resetPeak() {
		this.peakDb.fill(-160);
	}
	resetMax() {
		this.readout.lmax = this.readout.fast;
	}
	async sync() {
		if (!this.ctx || !this.running) return;
		const s = useSettings.getState();
		const ctx = this.ctx;
		const now = ctx.currentTime;
		const ramp = (g, value) => {
			if (!g) return;
			g.gain.cancelScheduledValues(now);
			g.gain.setTargetAtTime(Math.max(0, value), now, .02);
		};
		const routeKey = `${s.source}|${s.scenario}|${Math.round(s.rpm)}|${s.blades}`;
		const routeChanged = routeKey !== this.routeKey;
		this.routeKey = routeKey;
		this.readout.source = s.source;
		this.readout.splAt0 = s.splAt0;
		this.readout.weighting = s.weighting;
		if (s.source === "mic") {
			const ask = ++this.micAsk;
			ramp(this.calGain, 0);
			ramp(this.oscGain, 0);
			try {
				await this.ensureMic();
				if (ask !== this.micAsk || useSettings.getState().source !== "mic") {
					this.releaseMic();
					return;
				}
				ramp(this.micGain, 1);
				ramp(this.monitor, 0);
				this.readout.error = null;
			} catch (err) {
				if (ask !== this.micAsk) return;
				this.readout.error = micMessage(err);
				ramp(this.micGain, 0);
				return;
			}
		} else {
			this.micAsk++;
			this.releaseMic();
			ramp(this.micGain, 0);
			this.readout.error = null;
			if (s.source === "ref") {
				const refRms = Math.pow(10, -36 / 20);
				ramp(this.calGain, 0);
				ramp(this.oscGain, refRms * Math.SQRT2);
				ramp(this.monitor, s.monitor ? .07 / refRms : 0);
			} else {
				const scenario = getScenario(s.scenario);
				const gain = scenarioGain(scenario.mode, s.rpm, s.blades, ctx.sampleRate, scenario.targetDb, 120);
				ramp(this.oscGain, 0);
				ramp(this.calGain, gain);
				const key = `${scenario.mode}|${s.rpm}|${s.blades}`;
				if (key !== this.synthKey) {
					this.synth?.port.postMessage({
						type: "set",
						mode: scenario.mode,
						rpm: s.rpm,
						blades: s.blades
					});
					this.synthKey = key;
				}
				const masterRms = Math.pow(10, (scenario.targetDb - 120) / 20);
				ramp(this.monitor, s.monitor ? .07 / masterRms : 0);
			}
		}
		if (routeChanged) this.resetIntegrators();
	}
	resetIntegrators() {
		this.seeded = false;
		this.zFast = 0;
		this.aFast = 0;
		this.cFast = 0;
		this.zSlow = 0;
		this.aSlow = 0;
		this.cSlow = 0;
		this.leqFast.clear();
		this.leqSlow.clear();
		this.leqAcc = 0;
		this.trendWrite = 0;
		this.trendHead = 0;
		this.trendCount = 0;
		this.lastFallback = 0;
		this.readout.fast = NaN;
		this.readout.slow = NaN;
		this.readout.leq1 = NaN;
		this.readout.leq10 = NaN;
		this.readout.cpeak = NaN;
		this.readout.crest = NaN;
		this.readout.kurtosis = NaN;
		this.readout.lmax = NaN;
		this.readout.diagnosis = null;
		this.lastShift = 0;
	}
	zeroGains() {
		this.calGain && (this.calGain.gain.value = 0);
		this.oscGain && (this.oscGain.gain.value = 0);
		this.micGain && (this.micGain.gain.value = 0);
		this.monitor && (this.monitor.gain.value = 0);
	}
	async ensure() {
		if (this.ctx) {
			await this.ctx.resume();
			return;
		}
		if (this.starting) return this.starting;
		this.starting = this.build();
		try {
			await this.starting;
		} finally {
			this.starting = null;
		}
	}
	async build() {
		const ctx = new (window.AudioContext || window.webkitAudioContext)();
		this.ctx = ctx;
		this.sampleRate = ctx.sampleRate;
		await ctx.resume();
		const master = ctx.createGain();
		master.gain.value = 1;
		this.master = master;
		const calGain = ctx.createGain();
		calGain.gain.value = 0;
		this.calGain = calGain;
		const oscGain = ctx.createGain();
		oscGain.gain.value = 0;
		this.oscGain = oscGain;
		const micGain = ctx.createGain();
		micGain.gain.value = 0;
		this.micGain = micGain;
		calGain.connect(master);
		oscGain.connect(master);
		micGain.connect(master);
		const osc = ctx.createOscillator();
		osc.type = "sine";
		osc.frequency.value = 1e3;
		osc.connect(oscGain);
		osc.start();
		this.osc = osc;
		const analyser = ctx.createAnalyser();
		analyser.fftSize = this.fftSize;
		analyser.smoothingTimeConstant = .62;
		analyser.minDecibels = -120;
		analyser.maxDecibels = 0;
		master.connect(analyser);
		this.analyser = analyser;
		const mute = ctx.createGain();
		mute.gain.value = 0;
		analyser.connect(mute);
		const monitor = ctx.createGain();
		monitor.gain.value = 0;
		master.connect(monitor);
		monitor.connect(ctx.destination);
		this.monitor = monitor;
		mute.connect(ctx.destination);
		this.attachLevelAnalysers(ctx, master);
		try {
			const blob = new Blob([WORKLET_SOURCE], { type: "application/javascript" });
			const url = URL.createObjectURL(blob);
			await ctx.audioWorklet.addModule(url);
			URL.revokeObjectURL(url);
			this.attachWorklet(ctx, master);
			this.readout.meter = "worklet";
		} catch {
			this.readout.meter = "analyser";
		}
		this.ensureBuffers();
		this.raf = requestAnimationFrame(this.loop);
	}
	attachLevelAnalysers(ctx, master) {
		const make = () => {
			const node = ctx.createAnalyser();
			node.fftSize = 2048;
			node.smoothingTimeConstant = 0;
			return node;
		};
		const chain = (sections) => {
			let node = master;
			for (const section of sections) {
				const iir = ctx.createIIRFilter(section.ff, section.fb);
				node.connect(iir);
				node = iir;
			}
			return node;
		};
		this.analyserA = make();
		this.analyserC = make();
		chain(designAWeighting(ctx.sampleRate)).connect(this.analyserA);
		chain(designCWeighting(ctx.sampleRate)).connect(this.analyserC);
		const mute = ctx.createGain();
		mute.gain.value = 0;
		this.analyserA.connect(mute);
		this.analyserC.connect(mute);
		mute.connect(ctx.destination);
	}
	attachWorklet(ctx, master) {
		const synth = new AudioWorkletNode(ctx, "pump-synth", {
			numberOfInputs: 0,
			numberOfOutputs: 1,
			outputChannelCount: [1]
		});
		synth.connect(this.calGain);
		this.synth = synth;
		const meter = new AudioWorkletNode(ctx, "pump-meter", {
			numberOfInputs: 3,
			numberOfOutputs: 1,
			outputChannelCount: [1]
		});
		this.meter = meter;
		meter.port.onmessage = (ev) => {
			this.sawMeter = true;
			this.readout.meter = "worklet";
			this.consume(ev.data);
		};
		master.connect(meter, 0, 0);
		let a = master;
		for (const section of designAWeighting(ctx.sampleRate)) {
			const iir = ctx.createIIRFilter(section.ff, section.fb);
			a.connect(iir);
			a = iir;
		}
		a.connect(meter, 0, 1);
		let c = master;
		for (const section of designCWeighting(ctx.sampleRate)) {
			const iir = ctx.createIIRFilter(section.ff, section.fb);
			c.connect(iir);
			c = iir;
		}
		c.connect(meter, 0, 2);
		const mute = ctx.createGain();
		mute.gain.value = 0;
		meter.connect(mute);
		mute.connect(ctx.destination);
	}
	async ensureMic() {
		if (this.micNode || !this.ctx || !this.micGain) return;
		if (!navigator.mediaDevices?.getUserMedia) throw new Error("no-mic");
		const stream = await navigator.mediaDevices.getUserMedia({
			audio: {
				echoCancellation: false,
				noiseSuppression: false,
				autoGainControl: false,
				channelCount: 1
			},
			video: false
		});
		this.micStream = stream;
		this.micNode = this.ctx.createMediaStreamSource(stream);
		this.micNode.connect(this.micGain);
	}
	releaseMic() {
		this.micNode?.disconnect();
		this.micNode = null;
		this.micStream?.getTracks().forEach((track) => track.stop());
		this.micStream = null;
	}
	ensureBuffers() {
		if (!this.analyser) return;
		const n = this.analyser.frequencyBinCount;
		if (this.freqDb.length === n) return;
		this.freqDb = new Float32Array(n);
		this.displayDb = new Float32Array(n);
		this.weighted = new Float32Array(n);
		this.peakDb = new Float32Array(n);
		this.peakDb.fill(-160);
		this.fftSize = this.analyser.fftSize;
		this.timeZ = new Float32Array(this.analyser.fftSize);
		this.timeA = new Float32Array(this.analyserA?.fftSize ?? 2048);
		this.timeC = new Float32Array(this.analyserC?.fftSize ?? 2048);
	}
	loop = () => {
		this.analyse();
		this.raf = requestAnimationFrame(this.loop);
	};
	analyse() {
		if (!this.running || this.frozen || !this.analyser || !this.ctx) return;
		this.ensureBuffers();
		this.sampleRate = this.ctx.sampleRate;
		if (!this.sawMeter) {
			this.readout.meter = "analyser";
			this.fallbackMeter();
		}
		this.analyser.getFloatFrequencyData(this.freqDb);
		const settings = useSettings.getState();
		const weighting = settings.weighting;
		const spl = settings.splAt0;
		const key = `${weighting}|${this.sampleRate}|${this.fftSize}`;
		if (key !== this.weightKey) {
			this.weights = new Float32Array(this.freqDb.length);
			for (let i = 0; i < this.weights.length; i++) {
				const f = i * this.sampleRate / this.fftSize;
				this.weights[i] = i === 0 ? 0 : weightDb(weighting, f);
			}
			this.weightKey = key;
			this.peakDb.fill(-160);
			this.trendCount = 0;
			this.trendHead = 0;
		}
		const n = this.freqDb.length;
		let power = 0;
		for (let i = 1; i < n; i++) {
			let d = this.freqDb[i] ?? -140;
			if (!Number.isFinite(d)) d = -140;
			const w = this.weights[i] ?? 0;
			const v = d + w;
			this.weighted[i] = v;
			power += Math.pow(10, v / 10);
		}
		const fast = this.heroFast(weighting);
		let shift = this.lastShift;
		if (Number.isFinite(fast) && power > 0) {
			const sumDb = 10 * Math.log10(power);
			const next = fast - spl - sumDb;
			if (Number.isFinite(next) && next < 60 && next > -60) shift = next;
		}
		this.lastShift = shift;
		const hold = settings.peakHold;
		for (let i = 0; i < n; i++) {
			const splDb = (i === 0 ? -160 : (this.weighted[i] ?? -140) + shift) + spl;
			this.displayDb[i] = splDb;
			if (hold && splDb > (this.peakDb[i] ?? -160)) this.peakDb[i] = splDb;
		}
		const now = performance.now();
		if (now - this.lastRow > 48) {
			this.lastRow = now;
			this.pushWaterfall();
		}
		this.updateOctave(fast);
		if (now - this.lastFeat > 180) {
			this.lastFeat = now;
			this.updateFeatures(settings.rpm, settings.blades);
		}
		this.readout.weighting = weighting;
		this.readout.splAt0 = spl;
		this.readout.source = settings.source;
	}
	heroFast(weighting) {
		if (weighting === "C") return this.levelFrom(this.cFast);
		if (weighting === "Z") return this.levelFrom(this.zFast);
		return this.levelFrom(this.aFast);
	}
	heroSlow(weighting) {
		if (weighting === "C") return this.levelFrom(this.cSlow);
		if (weighting === "Z") return this.levelFrom(this.zSlow);
		return this.levelFrom(this.aSlow);
	}
	levelFrom(ms) {
		return dbOf(ms, useSettings.getState().splAt0);
	}
	fallbackMeter() {
		if (!this.analyser || !this.analyserA || !this.analyserC) return;
		this.analyser.getFloatTimeDomainData(this.timeZ);
		this.analyserA.getFloatTimeDomainData(this.timeA);
		this.analyserC.getFloatTimeDomainData(this.timeC);
		const pack = (buf) => {
			let s2 = 0;
			let s4 = 0;
			let pk = 0;
			for (let i = 0; i < buf.length; i++) {
				const x = buf[i] ?? 0;
				const x2 = x * x;
				s2 += x2;
				s4 += x2 * x2;
				const ax = Math.abs(x);
				if (ax > pk) pk = ax;
			}
			const n = buf.length || 1;
			return {
				ms: s2 / n,
				k: s4 / n,
				pk
			};
		};
		const z = pack(this.timeZ);
		const a = pack(this.timeA);
		const c = pack(this.timeC);
		const nowMs = performance.now();
		const dt = this.lastFallback ? Math.min(.1, (nowMs - this.lastFallback) / 1e3) : .05;
		this.lastFallback = nowMs;
		this.consume({
			dt,
			zMs: z.ms,
			zK: z.k,
			zPk: z.pk,
			aMs: a.ms,
			cMs: c.ms,
			cPk: c.pk
		});
	}
	consume(msg) {
		if (!this.running || this.frozen) return;
		const dt = Math.max(.01, msg.dt);
		if (!this.seeded) {
			this.zFast = msg.zMs;
			this.aFast = msg.aMs;
			this.cFast = msg.cMs;
			this.zSlow = msg.zMs;
			this.aSlow = msg.aMs;
			this.cSlow = msg.cMs;
			this.seeded = true;
		} else {
			this.zFast = smooth(this.zFast, msg.zMs, dt, .125);
			this.aFast = smooth(this.aFast, msg.aMs, dt, .125);
			this.cFast = smooth(this.cFast, msg.cMs, dt, .125);
			this.zSlow = smooth(this.zSlow, msg.zMs, dt, 1);
			this.aSlow = smooth(this.aSlow, msg.aMs, dt, 1);
			this.cSlow = smooth(this.cSlow, msg.cMs, dt, 1);
		}
		const weighting = useSettings.getState().weighting;
		const spl = useSettings.getState().splAt0;
		const ms = weighting === "C" ? msg.cMs : weighting === "Z" ? msg.zMs : msg.aMs;
		this.leqAcc += dt;
		if (this.leqAcc >= .05) {
			this.leqAcc = 0;
			this.leqFast.push(ms);
			this.leqSlow.push(ms);
		}
		const fast = this.heroFast(weighting);
		const audible = msg.zMs > 1e-10;
		const crest = audible ? msg.zPk / Math.sqrt(msg.zMs) : 0;
		const kurtosis = audible ? msg.zK / (msg.zMs * msg.zMs) : 0;
		this.readout.fast = fast;
		this.readout.slow = this.heroSlow(weighting);
		this.readout.leq1 = this.leqFast.db(spl);
		this.readout.leq10 = this.leqSlow.db(spl);
		this.readout.cpeak = dbOf(msg.cPk * msg.cPk, spl);
		this.readout.crest = crest;
		this.readout.kurtosis = kurtosis;
		this.readout.clipped = msg.zPk > .98;
		this.readout.splAt0 = spl;
		this.readout.weighting = weighting;
		if (!Number.isFinite(this.readout.lmax) || fast > this.readout.lmax) this.readout.lmax = fast;
		this.trendWrite += dt;
		if (this.trendWrite >= .1) {
			this.trendWrite -= .1;
			this.trend[this.trendHead] = fast;
			this.trendHead = (this.trendHead + 1) % this.trend.length;
			if (this.trendCount < this.trend.length) this.trendCount++;
		}
	}
	pushWaterfall() {
		const cols = this.waterfallCols;
		const db = this.displayDb;
		const sr = this.sampleRate;
		const fft = this.fftSize;
		const n = db.length;
		if (n < 8) return;
		const logMin = Math.log(20);
		const logMax = Math.log(Math.min(2e4, sr / 2));
		for (let x = 0; x < cols; x++) {
			const fLo = Math.exp(logMin + x / cols * (logMax - logMin));
			const fHi = Math.exp(logMin + (x + 1) / cols * (logMax - logMin));
			let i1 = Math.max(1, Math.floor(fLo * fft / sr));
			let i2 = Math.min(n - 1, Math.ceil(fHi * fft / sr));
			if (i2 < i1) i2 = i1;
			let m = -200;
			for (let i = i1; i <= i2; i++) {
				const v = db[i] ?? -200;
				if (v > m) m = v;
			}
			this.rowTmp[x] = m;
		}
		this.waterfall.set(this.rowTmp, this.waterfallHead * cols);
		this.waterfallHead = (this.waterfallHead + 1) % this.waterfallRows;
	}
	updateOctave(fast) {
		const bands = synthesizeOctave(this.displayDb, this.sampleRate, this.fftSize);
		if (Number.isFinite(fast)) {
			let p = 0;
			for (let i = 0; i < bands.length; i++) p += Math.pow(10, (bands[i] ?? -140) / 10);
			if (p > 0) {
				const shift = fast - 10 * Math.log10(p);
				if (Number.isFinite(shift) && Math.abs(shift) < 40) for (let i = 0; i < bands.length; i++) bands[i] = (bands[i] ?? -140) + shift;
			}
		}
		if (this.octaveDb.length !== bands.length) this.octaveDb = new Float32Array(bands.length);
		this.octaveDb.set(bands);
	}
	updateFeatures(rpm, blades) {
		if (!this.seeded) return;
		const spec = spectralFeatures(this.freqDb, this.sampleRate, this.fftSize, rpm, blades);
		this.readout.dominantHz = spec.dominantHz;
		this.readout.flatness = spec.flatness;
		this.readout.hfRatio = spec.hfRatio;
		this.readout.diagnosis = diagnose({
			...spec,
			level: this.readout.fast,
			crest: this.readout.crest,
			kurtosis: this.readout.kurtosis
		});
	}
};
function micMessage(err) {
	const name = err instanceof DOMException ? err.name : err instanceof Error ? err.message : "";
	if (name === "no-mic") return "这个环境没有麦克风，请用演示声源。";
	if (name === "NotAllowedError" || name === "SecurityError") return "没有麦克风权限。可以继续听演示声源，或在浏览器里允许麦克风。";
	if (name === "NotFoundError") return "没有找到麦克风。";
	return "麦克风没有打开，已回到演示声源。";
}
var slot = globalThis;
slot.__pumpEngine?.engine.dispose();
var engine = new Engine();
slot.__pumpEngine = { engine };
function downloadCsv() {
	const s = useSettings.getState();
	const r = engine.readout;
	const lines = [
		"项目,数值",
		`计权,${r.weighting}`,
		`快挡,${num(r.fast)}`,
		`慢挡,${num(r.slow)}`,
		`等效1秒,${num(r.leq1)}`,
		`等效10秒,${num(r.leq10)}`,
		`C峰值,${num(r.cpeak)}`,
		`主频Hz,${num(r.dominantHz)}`,
		`峭度,${num(r.kurtosis)}`,
		`波峰因数,${num(r.crest)}`,
		`转速,${s.rpm}`,
		`叶片,${s.blades}`,
		`判读,${r.diagnosis?.title ?? ""}`,
		"",
		"频率Hz,声级dB"
	];
	const n = engine.displayDb.length;
	const step = Math.max(1, Math.floor(n / 600));
	for (let i = 1; i < n; i += step) {
		const f = i * engine.sampleRate / engine.fftSize;
		lines.push(`${f.toFixed(2)},${(engine.displayDb[i] ?? 0).toFixed(2)}`);
	}
	lines.push("", "倍频程Hz,声级dB");
	for (let i = 0; i < THIRD_OCTAVE.length; i++) lines.push(`${THIRD_OCTAVE[i].fc},${(engine.octaveDb[i] ?? 0).toFixed(2)}`);
	const blob = new Blob(["﻿" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
	const a = document.createElement("a");
	a.href = URL.createObjectURL(blob);
	a.download = "泵声观测.csv";
	a.click();
	URL.revokeObjectURL(a.href);
}
function num(n) {
	return Number.isFinite(n) ? n.toFixed(2) : "";
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function fmtDb(n) {
	if (!Number.isFinite(n)) return "—";
	return n.toFixed(1);
}
function fmtHz(n) {
	if (!Number.isFinite(n) || n <= 0) return "—";
	if (n >= 1e3) return `${(n / 1e3).toFixed(2)} kHz`;
	return `${n.toFixed(1)} Hz`;
}
function fmtNum(n, digits = 2) {
	if (!Number.isFinite(n)) return "—";
	return n.toFixed(digits);
}
function Panel({ title, hint, action, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("min-w-0 rounded-2xl bg-surface p-2 shadow-panel", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3 px-2 py-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-fg",
					children: title
				}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: hint
				}) : null]
			}), action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0",
				children: action
			}) : null]
		}), children]
	});
}
var controlClass = "inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-raised px-3 text-sm text-fg shadow-panel disabled:cursor-not-allowed disabled:opacity-40";
function useFrame(ms = 100) {
	const [n, setN] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setN((v) => (v + 1) % 1e6), ms);
		return () => window.clearInterval(id);
	}, [ms]);
	return n;
}
var ICONS = {
	healthy: Check,
	cavitation: Waves,
	imbalance: Gauge,
	looseness: Unplug,
	bearing: TriangleAlert,
	mixed: CircleHelp,
	silence: MicOff,
	ref: AudioLines
};
var TONE = {
	healthy: "text-signal",
	cavitation: "text-alarm",
	bearing: "text-alarm",
	imbalance: "text-amber",
	looseness: "text-amber",
	mixed: "text-fg",
	silence: "text-muted",
	ref: "text-fg"
};
function DiagnosisCard() {
	useFrame(200);
	const result = engine.readout.running ? engine.readout.diagnosis : null;
	const Icon = result ? ICONS[result.id] : CircleHelp;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "工况线索",
		hint: "按当前转速和叶片数核对转频、叶片通过频率和半阶次",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-2 pb-3",
			children: [result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: cn("size-5", TONE[result.id]),
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: cn("text-lg font-medium", TONE[result.id]),
							"data-testid": "diagnosis",
							children: result.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-xs text-muted",
							children: ["把握 ", result.confidence]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-fg",
					children: result.summary
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-wrap gap-2",
					children: result.evidence.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-md bg-bg px-2 py-1 font-mono text-xs text-muted",
						children: item
					}, item))
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "开始观测后，这里会根据谱形给出排查方向：汽蚀看高频宽带，不平衡看 1 倍转频，松动看半阶次，轴承冲击看峭度。演示声源不需要麦克风。"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted",
				children: "线索不是故障结论，也不能代替振动检测。"
			})]
		})
	});
}
var WEIGHTS = [
	{
		id: "A",
		hint: "听感"
	},
	{
		id: "C",
		hint: "峰值"
	},
	{
		id: "Z",
		hint: "线性"
	}
];
function fastName(w) {
	if (w === "A") return "LAF";
	if (w === "C") return "LCF";
	return "LZF";
}
function leqName(w) {
	if (w === "A") return "LAeq";
	if (w === "C") return "LCeq";
	return "LZeq";
}
function useReadout() {
	useFrame(100);
	return engine.readout;
}
function MeterCard() {
	const snap = useReadout();
	const weighting = useSettings((s) => s.weighting);
	const update = useSettings((s) => s.update);
	const splAt0 = useSettings((s) => s.splAt0);
	const warn = useSettings((s) => s.warn);
	const danger = useSettings((s) => s.danger);
	const source = useSettings((s) => s.source);
	const scenario = useSettings((s) => s.scenario);
	const pushAlarm = useSettings((s) => s.pushAlarm);
	const armed = (0, import_react.useRef)(false);
	const scenarioName = getScenario(scenario).name;
	(0, import_react.useEffect)(() => {
		if (!snap.running || snap.frozen || !Number.isFinite(snap.fast) || source === "ref") {
			if (source === "ref" || !snap.running) armed.current = snap.fast >= danger;
			return;
		}
		if (snap.fast >= danger && !armed.current) pushAlarm({
			at: (/* @__PURE__ */ new Date()).toISOString(),
			db: snap.fast,
			note: source === "mic" ? "麦克风" : scenarioName
		});
		armed.current = snap.fast >= danger;
	}, [
		snap.fast,
		snap.running,
		snap.frozen,
		danger,
		source,
		scenarioName,
		pushAlarm
	]);
	const nominal = source === "ref" ? splAt0 + -36 : source === "demo" ? getScenario(scenario).targetDb + (splAt0 - 120) : null;
	const showDelta = snap.running && nominal !== null && Number.isFinite(snap.fast);
	const delta = showDelta ? snap.fast - nominal : 0;
	const hot = snap.running && snap.fast >= danger;
	const warm = snap.running && snap.fast >= warn && !hot;
	const tone = hot ? "text-alarm" : warm ? "text-amber" : snap.running ? "text-signal" : "text-muted";
	const bar = hot ? "bg-alarm" : warm ? "bg-amber" : "bg-signal";
	const pct = Number.isFinite(snap.fast) ? clamp((snap.fast - (splAt0 - 100)) / 100, 0, 1) : 0;
	const warnX = clamp((warn - (splAt0 - 100)) / 100, 0, 1) * 100;
	const dangerX = clamp((danger - (splAt0 - 100)) / 100, 0, 1) * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "min-w-0 rounded-2xl bg-surface p-4 shadow-panel",
		"data-meter": snap.meter,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-fg",
					children: "声级"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs text-muted",
					children: [fastName(weighting), " · 快挡 125 ms"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-2 font-mono text-6xl font-medium tabular-nums tracking-tight", tone),
				"data-testid": "level",
				children: fmtDb(snap.fast)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"dB · ",
					weighting,
					" 计权"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-4 h-2 rounded-full bg-bg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("h-full rounded-full", bar),
						style: { width: `${pct * 100}%` }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute top-0 h-full w-px bg-amber",
						style: { left: `${warnX}%` }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute top-0 h-full w-px bg-alarm",
						style: { left: `${dangerX}%` }
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex justify-between font-mono text-xs text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: Math.round(splAt0 - 100) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: Math.round(splAt0) })]
			}),
			hot || warm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-3 rounded-lg border-l-4 bg-bg px-3 py-2 text-sm text-fg", hot ? "border-alarm" : "border-amber"),
				children: hot ? `超过危险阈值 ${danger.toFixed(0)} dB` : `超过警告阈值 ${warn.toFixed(0)} dB`
			}) : null,
			snap.clipped ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 rounded-lg border-l-4 border-alarm bg-bg px-3 py-2 text-sm text-fg",
				children: "输入削波，读数不再可信。"
			}) : null,
			showDelta ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted",
				children: [
					source === "ref" ? "相对自检目标" : "相对该工况名义声级",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: cn("font-mono tabular-nums", source === "ref" && Math.abs(delta) > 1.5 ? "text-alarm" : "text-fg"),
						children: [
							delta >= 0 ? "+" : "",
							delta.toFixed(1),
							" dB"
						]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "刻度是相对满度。没有校准器时，把它当作变化量，不要当成法定声级。"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid grid-cols-3 gap-1 rounded-lg bg-bg p-1",
				role: "group",
				"aria-label": "频率计权",
				children: WEIGHTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": weighting === item.id,
					onClick: () => update({ weighting: item.id }),
					className: cn("h-11 rounded-md text-sm", weighting === item.id ? "bg-amber text-ink" : "text-muted"),
					children: [item.id, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-1 text-xs",
						children: item.hint
					})]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "慢挡 1 s",
						value: fmtDb(snap.slow)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: `${leqName(weighting)} 1 秒`,
						value: fmtDb(snap.leq1)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: `${leqName(weighting)} 10 秒`,
						value: fmtDb(snap.leq10)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "LC 峰值",
						value: fmtDb(snap.cpeak)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "本段最大",
						value: fmtDb(snap.lmax)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "主频",
						value: fmtHz(snap.dominantHz)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "峭度",
						value: fmtNum(snap.kurtosis, 1)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "波峰因数",
						value: fmtNum(snap.crest, 2)
					})
				]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-bg px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-mono text-base tabular-nums text-fg",
			children: value
		})]
	});
}
var cached = null;
function palette() {
	if (cached) return cached;
	const cs = getComputedStyle(document.documentElement);
	const pick = (name, fallback) => cs.getPropertyValue(name).trim() || fallback;
	cached = {
		bg: pick("--color-bg", "#0b0f12"),
		fg: pick("--color-fg", "#e7eee9"),
		muted: pick("--color-muted", "#93a09a"),
		line: pick("--color-line", "#2c3840"),
		amber: pick("--color-amber", "#e6a23c"),
		signal: pick("--color-signal", "#3dbea5"),
		alarm: pick("--color-alarm", "#e25b4a")
	};
	return cached;
}
function resizeCanvas(canvas) {
	const dpr = Math.min(2, window.devicePixelRatio || 1);
	const rect = canvas.getBoundingClientRect();
	const cssW = Math.max(1, rect.width);
	const cssH = Math.max(1, rect.height);
	const bw = Math.max(1, Math.round(cssW * dpr));
	const bh = Math.max(1, Math.round(cssH * dpr));
	if (canvas.width !== bw || canvas.height !== bh) {
		canvas.width = bw;
		canvas.height = bh;
	}
	return {
		dpr,
		cssW,
		cssH,
		bw,
		bh
	};
}
var F_MIN = 20;
function fMax(sampleRate) {
	return Math.min(2e4, Math.max(1e3, sampleRate / 2));
}
function freqToX(freq, plotW, sampleRate) {
	const min = Math.log(F_MIN);
	const max = Math.log(fMax(sampleRate));
	const f = clamp(freq, F_MIN, fMax(sampleRate));
	return (Math.log(f) - min) / (max - min) * plotW;
}
function xToFreq(x, plotW, sampleRate) {
	const min = Math.log(F_MIN);
	const max = Math.log(fMax(sampleRate));
	const t = clamp(x / Math.max(1, plotW), 0, 1);
	return Math.exp(min + t * (max - min));
}
function dbToY(db, plotH, splAt0) {
	return plotH - clamp((db - (splAt0 - 100)) / 100, 0, 1) * plotH;
}
var HEAT = /* @__PURE__ */ new Uint8ClampedArray(768);
var STOPS = [
	[
		0,
		11,
		15,
		18
	],
	[
		.2,
		14,
		72,
		68
	],
	[
		.48,
		61,
		190,
		165
	],
	[
		.76,
		230,
		162,
		60
	],
	[
		1,
		247,
		240,
		226
	]
];
for (let i = 0; i < 256; i++) {
	const t = i / 255;
	let j = 0;
	while (j < STOPS.length - 2 && t > STOPS[j + 1][0]) j++;
	const a = STOPS[j];
	const b = STOPS[j + 1];
	const u = (t - a[0]) / (b[0] - a[0] || 1);
	HEAT[i * 3] = Math.round(a[1] + (b[1] - a[1]) * u);
	HEAT[i * 3 + 1] = Math.round(a[2] + (b[2] - a[2]) * u);
	HEAT[i * 3 + 2] = Math.round(a[3] + (b[3] - a[3]) * u);
}
function heatIndex(db, splAt0) {
	const t = (db - (splAt0 - 100)) / 100;
	return clamp(Math.round(t * 255), 0, 255);
}
var SPEC = {
	l: 46,
	r: 8,
	t: 10,
	b: 22
};
function drawSpectrum(canvas, db, peak, sampleRate, fftSize, splAt0, rpm, blades, cursorFrac) {
	const { dpr, cssW, cssH } = resizeCanvas(canvas);
	const ctx = canvas.getContext("2d");
	if (!ctx) return null;
	const pal = palette();
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	ctx.fillStyle = pal.bg;
	ctx.fillRect(0, 0, cssW, cssH);
	const plotW = cssW - SPEC.l - SPEC.r;
	const plotH = cssH - SPEC.t - SPEC.b;
	ctx.font = "11px 'IBM Plex Mono', ui-monospace, monospace";
	ctx.lineWidth = 1;
	ctx.strokeStyle = pal.line;
	ctx.fillStyle = pal.muted;
	ctx.textAlign = "right";
	ctx.textBaseline = "middle";
	for (let dbTick = 0; dbTick <= 100; dbTick += 20) {
		const y = SPEC.t + dbToY(splAt0 - dbTick, plotH, splAt0);
		ctx.beginPath();
		ctx.moveTo(SPEC.l, y);
		ctx.lineTo(SPEC.l + plotW, y);
		ctx.stroke();
		ctx.fillText(String(Math.round(splAt0 - dbTick)), SPEC.l - 6, y);
	}
	ctx.textAlign = "center";
	ctx.textBaseline = "top";
	for (const freq of [
		20,
		100,
		1e3,
		1e4
	]) {
		if (freq >= fMax(sampleRate)) continue;
		const x = SPEC.l + freqToX(freq, plotW, sampleRate);
		ctx.beginPath();
		ctx.moveTo(x, SPEC.t);
		ctx.lineTo(x, SPEC.t + plotH);
		ctx.stroke();
		ctx.fillText(freq >= 1e3 ? `${freq / 1e3}k` : String(freq), x, SPEC.t + plotH + 6);
	}
	let hover = null;
	if (db.length > 8 && plotW > 8) {
		const cols = new Array(Math.ceil(plotW));
		const n = db.length;
		for (let x = 0; x < cols.length; x++) {
			const fLo = xToFreq(x, plotW, sampleRate);
			const fHi = xToFreq(x + 1, plotW, sampleRate);
			let i1 = Math.max(1, Math.floor(fLo * fftSize / sampleRate));
			let i2 = Math.min(n - 1, Math.ceil(fHi * fftSize / sampleRate));
			if (i2 < i1) i2 = i1;
			let m = -200;
			for (let i = i1; i <= i2; i++) {
				const v = db[i] ?? -200;
				if (v > m) m = v;
			}
			cols[x] = m;
		}
		ctx.beginPath();
		cols.forEach((v, x) => {
			const y = SPEC.t + dbToY(v, plotH, splAt0);
			if (x === 0) ctx.moveTo(SPEC.l + x, y);
			else ctx.lineTo(SPEC.l + x, y);
		});
		ctx.lineTo(SPEC.l + cols.length, SPEC.t + plotH);
		ctx.lineTo(SPEC.l, SPEC.t + plotH);
		ctx.closePath();
		ctx.fillStyle = withAlpha(pal.signal, .16);
		ctx.fill();
		ctx.beginPath();
		cols.forEach((v, x) => {
			const y = SPEC.t + dbToY(v, plotH, splAt0);
			if (x === 0) ctx.moveTo(SPEC.l + x, y);
			else ctx.lineTo(SPEC.l + x, y);
		});
		ctx.strokeStyle = pal.signal;
		ctx.lineWidth = 1.5;
		ctx.stroke();
		if (peak && peak.length === db.length) {
			ctx.beginPath();
			let started = false;
			for (let x = 0; x < cols.length; x++) {
				const fLo = xToFreq(x, plotW, sampleRate);
				const fHi = xToFreq(x + 1, plotW, sampleRate);
				let i1 = Math.max(1, Math.floor(fLo * fftSize / sampleRate));
				let i2 = Math.min(n - 1, Math.ceil(fHi * fftSize / sampleRate));
				if (i2 < i1) i2 = i1;
				let m = -200;
				for (let i = i1; i <= i2; i++) {
					const v = peak[i] ?? -200;
					if (v > m) m = v;
				}
				const y = SPEC.t + dbToY(m, plotH, splAt0);
				if (!started) {
					ctx.moveTo(SPEC.l + x, y);
					started = true;
				} else ctx.lineTo(SPEC.l + x, y);
			}
			ctx.strokeStyle = pal.amber;
			ctx.lineWidth = 1;
			ctx.stroke();
		}
		if (rpm >= 300) {
			mark(ctx, pal.amber, SPEC.l + freqToX(rpm / 60, plotW, sampleRate), SPEC.t, plotH, "1×");
			const bpf = rpm / 60 * blades;
			if (bpf < fMax(sampleRate)) mark(ctx, pal.fg, SPEC.l + freqToX(bpf, plotW, sampleRate), SPEC.t, plotH, "BPF");
		}
		if (cursorFrac !== null) {
			const x = clamp(cursorFrac * cssW, SPEC.l, SPEC.l + plotW) - SPEC.l;
			const col = clamp(Math.round(x), 0, cols.length - 1);
			hover = {
				hz: xToFreq(col, plotW, sampleRate),
				db: cols[col] ?? NaN
			};
			ctx.strokeStyle = pal.fg;
			ctx.lineWidth = 1;
			ctx.beginPath();
			ctx.moveTo(SPEC.l + col, SPEC.t);
			ctx.lineTo(SPEC.l + col, SPEC.t + plotH);
			ctx.stroke();
		}
	} else {
		ctx.fillStyle = pal.muted;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.font = "13px 'IBM Plex Sans', sans-serif";
		ctx.fillText("开始观测后显示频谱", SPEC.l + plotW / 2, SPEC.t + plotH / 2);
	}
	return hover;
}
function mark(ctx, color, x, top, plotH, label) {
	ctx.strokeStyle = color;
	ctx.lineWidth = 1;
	ctx.setLineDash([3, 3]);
	ctx.beginPath();
	ctx.moveTo(x, top);
	ctx.lineTo(x, top + plotH);
	ctx.stroke();
	ctx.setLineDash([]);
	ctx.fillStyle = color;
	ctx.textAlign = "left";
	ctx.textBaseline = "top";
	ctx.fillText(label, x + 4, top + 4);
}
var images = /* @__PURE__ */ new WeakMap();
function drawWaterfall(canvas, data, cols, rows, head, splAt0, active) {
	const { bw, bh } = resizeCanvas(canvas);
	const ctx = canvas.getContext("2d");
	if (!ctx) return;
	let img = images.get(canvas);
	if (!img || img.width !== bw || img.height !== bh) {
		img = ctx.createImageData(bw, bh);
		images.set(canvas, img);
	}
	const px = img.data;
	let seen = false;
	for (let y = 0; y < bh; y++) {
		const rowIndex = Math.min(rows - 1, Math.floor(y / bh * rows));
		const base = (head - 1 - rowIndex + rows * 4) % rows * cols;
		for (let x = 0; x < bw; x++) {
			const db = data[base + Math.min(cols - 1, Math.floor(x / bw * cols))] ?? -200;
			if (db > -120) seen = true;
			const hi = heatIndex(db, splAt0) * 3;
			const o = (y * bw + x) * 4;
			px[o] = HEAT[hi] ?? 0;
			px[o + 1] = HEAT[hi + 1] ?? 0;
			px[o + 2] = HEAT[hi + 2] ?? 0;
			px[o + 3] = 255;
		}
	}
	ctx.setTransform(1, 0, 0, 1, 0, 0);
	ctx.putImageData(img, 0, 0);
	if (!seen) {
		const pal = palette();
		const { dpr, cssW, cssH } = resizeCanvas(canvas);
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		ctx.fillStyle = pal.muted;
		ctx.font = "13px 'IBM Plex Sans', sans-serif";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText(active ? "正在积累瀑布…" : "瀑布图等待采样", cssW / 2, cssH / 2);
	}
}
function drawTrend(canvas, trend, head, count, splAt0, warn, danger) {
	const { dpr, cssW, cssH } = resizeCanvas(canvas);
	const ctx = canvas.getContext("2d");
	if (!ctx) return;
	const pal = palette();
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	ctx.fillStyle = pal.bg;
	ctx.fillRect(0, 0, cssW, cssH);
	const l = 46;
	const r = 8;
	const t = 10;
	const b = 18;
	const plotW = cssW - l - r;
	const plotH = cssH - t - b;
	ctx.font = "11px 'IBM Plex Mono', ui-monospace, monospace";
	ctx.fillStyle = pal.muted;
	ctx.textAlign = "right";
	ctx.textBaseline = "middle";
	ctx.strokeStyle = pal.line;
	ctx.lineWidth = 1;
	for (const dbTick of [
		0,
		50,
		100
	]) {
		const y = t + dbToY(splAt0 - dbTick, plotH, splAt0);
		ctx.beginPath();
		ctx.moveTo(l, y);
		ctx.lineTo(l + plotW, y);
		ctx.stroke();
		ctx.fillText(String(Math.round(splAt0 - dbTick)), 40, y);
	}
	rule(ctx, pal.amber, l, plotW, t, plotH, splAt0, warn);
	rule(ctx, pal.alarm, l, plotW, t, plotH, splAt0, danger);
	if (count < 2) {
		ctx.fillStyle = pal.muted;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.font = "13px 'IBM Plex Sans', sans-serif";
		ctx.fillText("采样后画出 60 秒曲线", l + plotW / 2, t + plotH / 2);
		return;
	}
	ctx.beginPath();
	ctx.strokeStyle = pal.signal;
	ctx.lineWidth = 1.5;
	for (let i = 0; i < count; i++) {
		const v = trend[(head - count + i + trend.length) % trend.length] ?? splAt0 - 100;
		const x = l + i / Math.max(1, count - 1) * plotW;
		const y = t + dbToY(v, plotH, splAt0);
		if (i === 0) ctx.moveTo(x, y);
		else ctx.lineTo(x, y);
	}
	ctx.stroke();
	ctx.fillStyle = pal.muted;
	ctx.textAlign = "left";
	ctx.textBaseline = "top";
	ctx.font = "11px 'IBM Plex Mono', ui-monospace, monospace";
	ctx.fillText("60 秒前", l, t + plotH + 4);
	ctx.textAlign = "right";
	ctx.fillText("现在", l + plotW, t + plotH + 4);
}
function rule(ctx, color, l, plotW, t, plotH, splAt0, db) {
	const y = t + dbToY(db, plotH, splAt0);
	ctx.strokeStyle = color;
	ctx.setLineDash([4, 4]);
	ctx.beginPath();
	ctx.moveTo(l, y);
	ctx.lineTo(l + plotW, y);
	ctx.stroke();
	ctx.setLineDash([]);
}
function withAlpha(color, alpha) {
	const hex = color.trim();
	const m = /^#([\da-f]{6})$/i.exec(hex);
	if (!m) return color;
	const n = parseInt(m[1], 16);
	return `rgba(${n >> 16 & 255}, ${n >> 8 & 255}, ${n & 255}, ${alpha})`;
}
function SpectrumView() {
	const canvasRef = (0, import_react.useRef)(null);
	const frac = (0, import_react.useRef)(null);
	const hoverText = (0, import_react.useRef)("指向频谱查看频率");
	const [hover, setHover] = (0, import_react.useState)("指向频谱查看频率");
	const peakHold = useSettings((s) => s.peakHold);
	const update = useSettings((s) => s.update);
	const splAt0 = useSettings((s) => s.splAt0);
	const rpm = useSettings((s) => s.rpm);
	const blades = useSettings((s) => s.blades);
	(0, import_react.useEffect)(() => {
		let id = 0;
		const loop = () => {
			const canvas = canvasRef.current;
			if (canvas) {
				const hit = drawSpectrum(canvas, engine.displayDb, peakHold ? engine.peakDb : null, engine.sampleRate, engine.fftSize, splAt0, rpm, blades, frac.current);
				if (hit && frac.current !== null) {
					const label = `${fmtHz(hit.hz)} · ${fmtDb(hit.db)} dB`;
					if (hoverText.current !== label) {
						hoverText.current = label;
						setHover(label);
					}
				}
			}
			id = requestAnimationFrame(loop);
		};
		id = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(id);
	}, [
		peakHold,
		splAt0,
		rpm,
		blades
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "频谱",
		hint: "对数频率 · 实线为实时 · 黄线为峰值保持",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": peakHold,
				className: cn(controlClass, "px-3", peakHold && "bg-amber text-ink"),
				onClick: () => update({ peakHold: !peakHold }),
				children: "峰值保持"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: controlClass,
				onClick: () => engine.resetPeak(),
				children: "清除"
			})]
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-2 pb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "block h-52 w-full cursor-crosshair rounded-lg bg-bg",
				"aria-label": "频谱",
				onPointerMove: (event) => {
					const rect = event.currentTarget.getBoundingClientRect();
					frac.current = (event.clientX - rect.left) / Math.max(1, rect.width);
				},
				onPointerLeave: () => {
					frac.current = null;
					hoverText.current = "指向频谱查看频率";
					setHover("指向频谱查看频率");
				}
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-mono text-xs text-muted",
				children: hover
			})]
		})
	});
}
function WaterfallView() {
	const canvasRef = (0, import_react.useRef)(null);
	const splAt0 = useSettings((s) => s.splAt0);
	(0, import_react.useEffect)(() => {
		let id = 0;
		const loop = () => {
			const canvas = canvasRef.current;
			if (canvas) drawWaterfall(canvas, engine.waterfall, engine.waterfallCols, engine.waterfallRows, engine.waterfallHead, splAt0, engine.readout.running);
			id = requestAnimationFrame(loop);
		};
		id = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(id);
	}, [splAt0]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "瀑布图",
		hint: "最新在上方 · 横轴 20 Hz 到 20 kHz · 颜色越亮声级越高",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-2 pb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "block h-44 w-full rounded-lg bg-bg",
				"aria-label": "瀑布图"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex justify-between px-1 font-mono text-xs text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "20 Hz" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1 kHz" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "20 kHz" })
				]
			})]
		})
	});
}
function OctaveView() {
	useFrame(100);
	const splAt0 = useSettings((s) => s.splAt0);
	const warn = useSettings((s) => s.warn);
	const danger = useSettings((s) => s.danger);
	const floor = splAt0 - 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "三分之一倍频程",
		hint: "按 IEC 61260 标称中心频率合成，总能量对齐当前快挡",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-2 pb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-40 items-end gap-px rounded-lg bg-bg px-2 pt-3",
				children: THIRD_OCTAVE.map((band, index) => {
					const db = engine.octaveDb[index] ?? NaN;
					const pct = Number.isFinite(db) ? clamp((db - floor) / 100 * 100, 0, 100) : 0;
					const color = db >= danger ? "bg-alarm" : db >= warn ? "bg-amber" : "bg-signal";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-full min-w-0 flex-1 items-end",
						title: `${band.label} · ${fmtDb(db)} dB`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("w-full rounded-sm", color),
							style: { height: `${pct}%` }
						})
					}, band.fc);
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mt-1 h-4 font-mono text-xs text-muted",
				children: THIRD_OCTAVE.map((band, index) => band.tick ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute -translate-x-1/2",
					style: { left: `${(index + .5) / THIRD_OCTAVE.length * 100}%` },
					children: band.label
				}, band.fc) : null)
			})]
		})
	});
}
function TrendView() {
	const canvasRef = (0, import_react.useRef)(null);
	const splAt0 = useSettings((s) => s.splAt0);
	const warn = useSettings((s) => s.warn);
	const danger = useSettings((s) => s.danger);
	const weighting = useSettings((s) => s.weighting);
	(0, import_react.useEffect)(() => {
		let id = 0;
		const loop = () => {
			const canvas = canvasRef.current;
			if (canvas) drawTrend(canvas, engine.trend, engine.trendHead, engine.trendCount, splAt0, warn, danger);
			id = requestAnimationFrame(loop);
		};
		id = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(id);
	}, [
		splAt0,
		warn,
		danger
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "六十秒趋势",
		hint: `${weighting === "A" ? "LAF" : weighting === "C" ? "LCF" : "LZF"} · 虚线为警告和危险`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-2 pb-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "block h-32 w-full rounded-lg bg-bg",
				"aria-label": "声级趋势"
			})
		})
	});
}
function SettingsPanel() {
	const rpm = useSettings((s) => s.rpm);
	const blades = useSettings((s) => s.blades);
	const splAt0 = useSettings((s) => s.splAt0);
	const warn = useSettings((s) => s.warn);
	const danger = useSettings((s) => s.danger);
	const monitor = useSettings((s) => s.monitor);
	const alarms = useSettings((s) => s.alarms);
	const update = useSettings((s) => s.update);
	const clearAlarms = useSettings((s) => s.clearAlarms);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: "校准、阈值和记录",
		hint: "这些设置只留在这台设备上",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 px-2 pb-2 sm:grid-cols-2 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "转速 r/min",
						value: rpm,
						min: 300,
						max: 6e3,
						step: 10,
						onChange: (value) => update({ rpm: value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "叶片数",
						value: blades,
						min: 2,
						max: 12,
						step: 1,
						onChange: (value) => update({ blades: value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "0 dBFS 对应 dB",
						value: splAt0,
						min: 80,
						max: 140,
						step: 1,
						onChange: (value) => update({ splAt0: value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "警告 dB",
						value: warn,
						min: 40,
						max: 130,
						step: 1,
						onChange: (value) => update({ warn: Math.min(value, danger - 1) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "危险 dB",
						value: danger,
						min: 45,
						max: 140,
						step: 1,
						onChange: (value) => update({ danger: Math.max(value, warn + 1) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": monitor,
							className: cn(controlClass, monitor && "bg-amber text-ink"),
							onClick: () => update({ monitor: !monitor }),
							children: monitor ? "监听开" : "监听关"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2 px-2 pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: controlClass,
						onClick: () => downloadCsv(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
							className: "size-4",
							"aria-hidden": "true"
						}), "导出频谱"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: controlClass,
						onClick: () => engine.resetMax(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
							className: "size-4",
							"aria-hidden": "true"
						}), "清除最大声级"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: controlClass,
						onClick: () => clearAlarms(),
						disabled: alarms.length === 0,
						children: "清除记录"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-2 pb-2",
				children: alarms.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "越过危险阈值时记在这里。自检正弦不记。"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-line",
					children: alarms.map((alarm, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 py-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: formatWhen(alarm.at)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate",
								children: alarm.note
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono tabular-nums text-alarm",
								children: [alarm.db.toFixed(1), " dB"]
							})
						]
					}, `${alarm.at}-${index}`))
				})
			})
		]
	});
}
function Field({ label, value, min, max, step, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "mt-1 h-11 w-full rounded-lg border border-line bg-bg px-3 font-mono text-base text-fg",
			type: "number",
			inputMode: "decimal",
			min,
			max,
			step,
			value: Number.isFinite(value) ? value : min,
			onChange: (event) => {
				const next = Number(event.target.value);
				if (!Number.isFinite(next)) return;
				onChange(clamp(next, min, max));
			}
		})]
	});
}
function formatWhen(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "";
	return date.toLocaleString("zh-CN", {
		hour12: false,
		month: "numeric",
		day: "numeric",
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	});
}
function Toolbar() {
	const source = useSettings((s) => s.source);
	const scenario = useSettings((s) => s.scenario);
	const selectScenario = useSettings((s) => s.selectScenario);
	const update = useSettings((s) => s.update);
	const current = getScenario(scenario);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [
				SCENARIOS.map((item) => {
					const on = source === "demo" && scenario === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": on,
						className: cn(controlClass, on && "bg-amber text-ink"),
						onClick: () => {
							selectScenario(item.id);
							engine.start();
						},
						children: item.name
					}, item.id);
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": source === "mic",
					className: cn(controlClass, source === "mic" && "bg-amber text-ink"),
					onClick: () => {
						update({ source: "mic" });
						engine.start();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {
						className: "size-4",
						"aria-hidden": "true"
					}), "麦克风"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": source === "ref",
					className: cn(controlClass, source === "ref" && "bg-amber text-ink"),
					onClick: () => {
						update({ source: "ref" });
						engine.start();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, {
						className: "size-4",
						"aria-hidden": "true"
					}), "1 kHz 自检"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: source === "mic" ? "已请求关闭回声消除、降噪和自动增益。手机增益仍会改变读数，用下方满度声级对齐声级计。" : source === "ref" ? "1 kHz 正弦，RMS 为 −36 dBFS。A、C、Z 在这个频率上应几乎重合。" : current.blurb
		})]
	});
}
function Instrument() {
	const load = useSettings((s) => s.load);
	const source = useSettings((s) => s.source);
	const scenario = useSettings((s) => s.scenario);
	const rpm = useSettings((s) => s.rpm);
	const blades = useSettings((s) => s.blades);
	const monitor = useSettings((s) => s.monitor);
	useFrame(250);
	const running = engine.readout.running;
	const frozen = engine.readout.frozen;
	const error = engine.readout.error;
	const [spoken, setSpoken] = (0, import_react.useState)("尚未开始采样");
	(0, import_react.useEffect)(() => {
		load();
	}, [load]);
	(0, import_react.useEffect)(() => {
		const id = window.setTimeout(() => {
			engine.sync();
		}, 140);
		return () => window.clearTimeout(id);
	}, [
		source,
		scenario,
		rpm,
		blades,
		monitor
	]);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			const level = engine.readout;
			if (!level.running || !Number.isFinite(level.fast)) {
				setSpoken("尚未开始采样");
				return;
			}
			setSpoken(`当前${level.weighting}计权快挡 ${level.fast.toFixed(0)} 分贝，主频 ${level.dominantHz.toFixed(0)} 赫兹`);
		}, 2e3);
		return () => window.clearInterval(id);
	}, []);
	const sourceLabel = source === "mic" ? "麦克风" : source === "ref" ? "1 kHz 自检" : "演示";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex w-full max-w-6xl flex-col gap-3 px-3 py-4 sm:px-5 sm:py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: spoken
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-11 items-center justify-center rounded-lg bg-amber text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, {
							className: "size-5",
							"aria-hidden": "true"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "现场声学"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-xl font-semibold text-fg",
						children: "泵声观测"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex h-11 items-center gap-2 rounded-lg bg-surface px-3 text-sm text-fg shadow-panel",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full", running && !frozen ? "bg-signal live-dot" : "bg-muted") }),
								frozen ? "已冻结" : running ? "采样中" : "待命",
								" · ",
								sourceLabel
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: cn(controlClass, !running && "bg-amber text-ink"),
							onClick: () => {
								if (running) engine.stop();
								else engine.start();
							},
							children: [running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
								className: "size-4",
								"aria-hidden": "true"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								className: "size-4",
								"aria-hidden": "true"
							}), running ? "停止" : "开始观测"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: controlClass,
							disabled: !running,
							onClick: () => engine.toggleFreeze(),
							children: frozen ? "继续" : "冻结"
						})
					]
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg border-l-4 border-alarm bg-surface px-3 py-2 text-sm text-fg",
				role: "alert",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toolbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeterCard, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-0 lg:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpectrumView, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaterfallView, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctaveView, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid min-w-0 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendView, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiagnosisCard, {})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-2xl bg-surface p-4 shadow-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "text-sm font-medium text-fg",
					children: "测量方法"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "声音在浏览器里处理，不上传。链路和开源网页声级计相同：Web Audio 的 AudioWorklet 计算时间计权，IIR 滤波器按 IEC 61672-1 的 A/C 计权极点做双线性变换，AnalyserNode 做加 Blackman 窗的 FFT。" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "快挡 125 ms、慢挡 1 s。等效声级是短时均方的能量平均。三分之一倍频程用 IEC 61260 的标称中心频率，由频谱功率合成后再对齐到快挡读数。瀑布图是对数频率上的短时谱。" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "故障线索来自公开的泵和旋转机械声学经验：叶片通过频率、转频过高、半阶次谐波、高频宽带抬升、峭度与波峰因数。演示声源是本地合成的，方便没有水泵时核对仪表。" })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "不能代替经检定的声级计或现场振动诊断。"
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instrument, {});
}
//#endregion
export { Home as component };
