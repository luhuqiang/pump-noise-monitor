/**
 * Pump synthesizer shared verbatim with an AudioWorklet.
 * Keep this string free of closures, template placeholders, and TypeScript.
 */
export const DSP_SOURCE = `
function createPumpState(mode, rpm, blades) {
  var twopi = 6.283185307179586;
  var s = {
    mode: mode | 0,
    rpm: rpm,
    blades: blades | 0,
    phase: new Float32Array(17),
    fphase: new Float32Array(4),
    seed: ((mode * 10007 + (rpm | 0) * 13 + (blades | 0) * 99) | 0) || 123456789,
    lp: 0,
    ring: 0,
    ringPhase: 0,
    n: 0,
  };
  var h, x;
  for (h = 0; h < 17; h++) {
    x = s.seed | 0;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    s.seed = x || 123456789;
    s.phase[h] = ((x >>> 0) / 4294967296) * twopi;
  }
  for (h = 0; h < 4; h++) {
    x = s.seed | 0;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    s.seed = x || 123456789;
    s.fphase[h] = ((x >>> 0) / 4294967296) * twopi;
  }
  return s;
}

function pumpSample(s, sr) {
  var f0 = s.rpm / 60;
  var dt = 1 / sr;
  var twopi = 6.283185307179586;
  var y = 0;
  var blades = s.blades | 0;
  var mode = s.mode | 0;
  var h, amp;

  for (h = 1; h <= 16; h++) {
    amp = 0;
    if (mode === 0) {
      if (h === 1) amp = 0.12;
      else if (h === 2) amp = 0.045;
      else if (h === 3) amp = 0.02;
      else if (h === blades) amp = 0.85;
      else if (h === blades * 2 && h <= 16) amp = 0.28;
    } else if (mode === 1) {
      if (h === 1) amp = 0.1;
      else if (h === blades) amp = 0.32;
      else if (h === blades * 2 && h <= 16) amp = 0.08;
    } else if (mode === 2) {
      if (h === 1) amp = 1;
      else if (h === 2) amp = 0.22;
      else if (h === 3) amp = 0.08;
      else if (h === blades) amp = 0.15;
    } else if (mode === 3) {
      amp = 0.48 / Math.sqrt(h);
    } else if (mode === 4) {
      if (h === 1) amp = 0.14;
      else if (h === 2) amp = 0.05;
      else if (h === blades) amp = 0.42;
    }
    if (amp > 0) {
      s.phase[h] += twopi * f0 * h * dt;
      if (s.phase[h] > twopi) s.phase[h] -= twopi;
      y += amp * Math.sin(s.phase[h]);
    }
  }

  if (mode === 3) {
    var fr = [0.5, 1.5, 2.5, 3.5];
    var fa = [0.72, 0.48, 0.32, 0.18];
    for (h = 0; h < 4; h++) {
      s.fphase[h] += twopi * f0 * fr[h] * dt;
      if (s.fphase[h] > twopi) s.fphase[h] -= twopi;
      y += fa[h] * Math.sin(s.fphase[h]);
    }
  }

  var x = s.seed | 0;
  x ^= x << 13;
  x ^= x >>> 17;
  x ^= x << 5;
  s.seed = x;
  var white = ((x >>> 0) / 4294967296) * 2 - 1;
  var alpha = mode === 1 ? 0.18 : 0.02;
  s.lp += alpha * (white - s.lp);
  var hp = white - s.lp;
  var nAmp = 0.06;
  var nSig = s.lp;
  if (mode === 1) {
    nAmp = 2.2;
    nSig = hp;
  } else if (mode === 3) {
    nAmp = 0.16;
    nSig = s.lp;
  } else if (mode === 4) {
    nAmp = 0.05;
    nSig = s.lp;
  }
  if (mode === 1) {
    var mod = 0.72 + 0.28 * Math.sin(twopi * 19 * s.n * dt);
    y += nAmp * nSig * mod;
  } else {
    y += nAmp * nSig;
  }

  if (mode === 4) {
    var rate = f0 * 3.07;
    var period = Math.max(8, Math.round(sr / rate));
    if (s.n % period === 0) s.ring = 1;
    s.ring *= Math.exp(-dt / 0.00065);
    s.ringPhase += twopi * 4200 * dt;
    if (s.ringPhase > twopi) s.ringPhase -= twopi;
    y += s.ring * Math.sin(s.ringPhase) * 11;
  }

  s.n++;
  if (y !== y) return 0;
  return y;
}
`;

export const WORKLET_SOURCE = `${DSP_SOURCE}
class PumpSynth extends AudioWorkletProcessor {
  constructor() {
    super();
    this.state = createPumpState(0, 2950, 6);
    this.port.onmessage = function (ev) {
      var d = ev.data || {};
      if (d.type === "set") {
        this.state = createPumpState(d.mode, d.rpm, d.blades);
      }
    }.bind(this);
  }
  process(inputs, outputs) {
    var out = outputs[0] && outputs[0][0];
    if (!out) return true;
    var i;
    for (i = 0; i < out.length; i++) out[i] = pumpSample(this.state, sampleRate);
    return true;
  }
}

class PumpMeter extends AudioWorkletProcessor {
  constructor() {
    super();
    this.z2 = 0;
    this.z4 = 0;
    this.zn = 0;
    this.a2 = 0;
    this.c2 = 0;
    this.zpk = 0;
    this.cpk = 0;
    this.hop = 0;
  }
  process(inputs, outputs) {
    var out = outputs[0] && outputs[0][0];
    if (out) out.fill(0);
    var z = inputs[0] && inputs[0][0];
    var a = inputs[1] && inputs[1][0];
    var c = inputs[2] && inputs[2][0];
    var n = z ? z.length : a ? a.length : c ? c.length : 0;
    if (!n) return true;
    var i, x, x2, ax;
    for (i = 0; i < n; i++) {
      if (z) {
        x = z[i];
        x2 = x * x;
        this.z2 += x2;
        this.z4 += x2 * x2;
        ax = x < 0 ? -x : x;
        if (ax > this.zpk) this.zpk = ax;
        this.zn++;
      }
      if (a) this.a2 += a[i] * a[i];
      if (c) {
        x = c[i];
        this.c2 += x * x;
        ax = x < 0 ? -x : x;
        if (ax > this.cpk) this.cpk = ax;
      }
    }
    this.hop += n;
    if (this.hop >= sampleRate * 0.05) {
      var zn = this.zn > 0 ? this.zn : 1;
      this.port.postMessage({
        dt: this.hop / sampleRate,
        zMs: this.z2 / zn,
        zK: this.z4 / zn,
        zPk: this.zpk,
        aMs: this.a2 / zn,
        cMs: this.c2 / zn,
        cPk: this.cpk,
      });
      this.z2 = 0;
      this.z4 = 0;
      this.a2 = 0;
      this.c2 = 0;
      this.zn = 0;
      this.zpk = 0;
      this.cpk = 0;
      this.hop = 0;
    }
    return true;
  }
}

registerProcessor("pump-synth", PumpSynth);
registerProcessor("pump-meter", PumpMeter);
`;

type PumpFns = {
  createPumpState: (mode: number, rpm: number, blades: number) => PumpState;
  pumpSample: (s: PumpState, sr: number) => number;
};

type PumpState = {
  mode: number;
  rpm: number;
  blades: number;
  phase: Float32Array;
  fphase: Float32Array;
  seed: number;
  lp: number;
  ring: number;
  ringPhase: number;
  n: number;
};

let fns: PumpFns | null = null;

export function getPumpFns(): PumpFns {
  if (!fns) {
    fns = new Function(`${DSP_SOURCE}; return { createPumpState, pumpSample };`)() as PumpFns;
  }
  return fns;
}

const gainCache = new Map<string, number>();

/** Linear gain that places the scenario at targetDb when 0 dBFS equals splRef. */
export function scenarioGain(
  mode: number,
  rpm: number,
  blades: number,
  sampleRate: number,
  targetDb: number,
  splRef: number,
) {
  const key = `${mode}|${rpm}|${blades}|${sampleRate}|${targetDb}|${splRef}`;
  const hit = gainCache.get(key);
  if (hit !== undefined) return hit;
  const { createPumpState, pumpSample } = getPumpFns();
  const state = createPumpState(mode, rpm, blades);
  const n = Math.min(sampleRate, 48000);
  let sum = 0;
  for (let i = 0; i < n; i++) {
    const y = pumpSample(state, sampleRate);
    sum += y * y;
  }
  const rms = Math.sqrt(sum / n) || 1e-9;
  const target = Math.pow(10, (targetDb - splRef) / 20);
  const gain = target / rms;
  gainCache.set(key, gain);
  return gain;
}
