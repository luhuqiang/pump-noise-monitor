import { THIRD_OCTAVE, synthesizeOctave } from "@/lib/audio/bands";
import { diagnose, type Diagnosis } from "@/lib/audio/diagnose";
import { spectralFeatures } from "@/lib/audio/features";
import { scenarioGain, WORKLET_SOURCE } from "@/lib/audio/pump-dsp";
import { getScenario, REF_DBFS } from "@/lib/audio/scenarios";
import { designAWeighting, designCWeighting, weightDb } from "@/lib/audio/weighting";
import { useSettings, type SourceMode, type Weighting } from "@/lib/settings";

export type Readout = {
  running: boolean;
  frozen: boolean;
  source: SourceMode;
  weighting: Weighting;
  fast: number;
  slow: number;
  leq1: number;
  leq10: number;
  cpeak: number;
  lmax: number;
  crest: number;
  kurtosis: number;
  dominantHz: number;
  flatness: number;
  hfRatio: number;
  splAt0: number;
  clipped: boolean;
  error: string | null;
  diagnosis: Diagnosis | null;
  meter: "worklet" | "analyser" | "idle";
};

type MeterMsg = {
  dt: number;
  zMs: number;
  zK: number;
  zPk: number;
  aMs: number;
  cMs: number;
  cPk: number;
};

const EMPTY: Readout = {
  running: false,
  frozen: false,
  source: "demo",
  weighting: "A",
  fast: Number.NaN,
  slow: Number.NaN,
  leq1: Number.NaN,
  leq10: Number.NaN,
  cpeak: Number.NaN,
  lmax: Number.NaN,
  crest: Number.NaN,
  kurtosis: Number.NaN,
  dominantHz: 0,
  flatness: Number.NaN,
  hfRatio: Number.NaN,
  splAt0: 120,
  clipped: false,
  error: null,
  diagnosis: null,
  meter: "idle",
};

function dbOf(ms: number, splAt0: number) {
  if (!(ms > 0)) return splAt0 - 120;
  return 10 * Math.log10(ms) + splAt0;
}

function smooth(prev: number, next: number, dt: number, tau: number) {
  const a = 1 - Math.exp(-dt / tau);
  return prev + a * (next - prev);
}

class Ring {
  private buf: number[] = [];
  private sum = 0;
  constructor(private max: number) {}
  clear() {
    this.buf = [];
    this.sum = 0;
  }
  push(ms: number) {
    this.buf.push(ms);
    this.sum += ms;
    if (this.buf.length > this.max) this.sum -= this.buf.shift() ?? 0;
  }
  db(splAt0: number) {
    if (!this.buf.length || this.sum <= 0) return Number.NaN;
    return 10 * Math.log10(this.sum / this.buf.length) + splAt0;
  }
}

export class Engine {
  readout: Readout = { ...EMPTY };
  displayDb = new Float32Array(0);
  peakDb = new Float32Array(0);
  octaveDb = new Float32Array(0);
  waterfall = new Float32Array(400 * 150);
  waterfallCols = 400;
  waterfallRows = 150;
  waterfallHead = 0;
  trend = new Float32Array(600);
  trendHead = 0;
  trendCount = 0;
  fftSize = 8192;
  sampleRate = 48000;

  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private calGain: GainNode | null = null;
  private oscGain: GainNode | null = null;
  private micGain: GainNode | null = null;
  private monitor: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private analyserA: AnalyserNode | null = null;
  private analyserC: AnalyserNode | null = null;
  private synth: AudioWorkletNode | null = null;
  private meter: AudioWorkletNode | null = null;
  private osc: OscillatorNode | null = null;
  private micNode: MediaStreamAudioSourceNode | null = null;
  private micStream: MediaStream | null = null;
  private freqDb = new Float32Array(0);
  private weighted = new Float32Array(0);
  private timeZ = new Float32Array(0);
  private timeA = new Float32Array(0);
  private timeC = new Float32Array(0);
  private rowTmp = new Float32Array(400);
  private raf = 0;
  private starting: Promise<void> | null = null;
  private sawMeter = false;
  private seeded = false;
  private zFast = 0;
  private aFast = 0;
  private cFast = 0;
  private zSlow = 0;
  private aSlow = 0;
  private cSlow = 0;
  private leqFast = new Ring(20);
  private leqSlow = new Ring(200);
  private trendWrite = 0;
  private leqAcc = 0;
  private lastFallback = 0;
  private lastRow = 0;
  private lastFeat = 0;
  private lastShift = 0;
  private weightKey = "";
  private weights = new Float32Array(0);
  private synthKey = "";
  private routeKey = "";
  private micAsk = 0;
  private frozen = false;
  private running = false;

  constructor() {
    this.waterfall.fill(-200);
    this.octaveDb = new Float32Array(31);
  }

  dispose() {
    this.running = false;
    this.frozen = false;
    cancelAnimationFrame(this.raf);
    this.raf = 0;
    this.releaseMic();
    this.osc?.stop();
    void this.ctx?.close();
    this.ctx = null;
    this.readout = { ...EMPTY };
  }

  async start() {
    if (this.running) {
      await this.sync();
      return;
    }
    await this.ensure();
    this.resetIntegrators();
    this.running = true;
    this.frozen = false;
    this.readout.running = true;
    this.readout.frozen = false;
    this.readout.error = null;
    await this.sync();
  }

  stop() {
    this.running = false;
    this.frozen = false;
    this.readout.running = false;
    this.readout.frozen = false;
    this.zeroGains();
    this.releaseMic();
  }

  toggleFreeze() {
    if (!this.running) return;
    this.frozen = !this.frozen;
    this.readout.frozen = this.frozen;
  }

  resetPeak() {
    this.peakDb.fill(-160);
  }

  resetMax() {
    this.readout.lmax = this.readout.fast;
  }

  async sync() {
    if (!this.ctx || !this.running) return;
    const s = useSettings.getState();
    const ctx = this.ctx;
    const now = ctx.currentTime;
    const ramp = (g: GainNode | null, value: number) => {
      if (!g) return;
      g.gain.cancelScheduledValues(now);
      g.gain.setTargetAtTime(Math.max(0, value), now, 0.02);
    };
    const routeKey = `${s.source}|${s.scenario}|${Math.round(s.rpm)}|${s.blades}`;
    const routeChanged = routeKey !== this.routeKey;
    this.routeKey = routeKey;

    this.readout.source = s.source;
    this.readout.splAt0 = s.splAt0;
    this.readout.weighting = s.weighting;

    if (s.source === "mic") {
      const ask = ++this.micAsk;
      ramp(this.calGain, 0);
      ramp(this.oscGain, 0);
      try {
        await this.ensureMic();
        if (ask !== this.micAsk || useSettings.getState().source !== "mic") {
          this.releaseMic();
          return;
        }
        ramp(this.micGain, 1);
        ramp(this.monitor, 0);
        this.readout.error = null;
      } catch (err) {
        if (ask !== this.micAsk) return;
        this.readout.error = micMessage(err);
        ramp(this.micGain, 0);
        return;
      }
    } else {
      this.micAsk++;
      this.releaseMic();
      ramp(this.micGain, 0);
      this.readout.error = null;
      if (s.source === "ref") {
        const refRms = Math.pow(10, REF_DBFS / 20);
        ramp(this.calGain, 0);
        ramp(this.oscGain, refRms * Math.SQRT2);
        ramp(this.monitor, s.monitor ? 0.07 / refRms : 0);
      } else {
        const scenario = getScenario(s.scenario);
        const gain = scenarioGain(
          scenario.mode,
          s.rpm,
          s.blades,
          ctx.sampleRate,
          scenario.targetDb,
          120,
        );
        ramp(this.oscGain, 0);
        ramp(this.calGain, gain);
        const key = `${scenario.mode}|${s.rpm}|${s.blades}`;
        if (key !== this.synthKey) {
          this.synth?.port.postMessage({
            type: "set",
            mode: scenario.mode,
            rpm: s.rpm,
            blades: s.blades,
          });
          this.synthKey = key;
        }
        const masterRms = Math.pow(10, (scenario.targetDb - 120) / 20);
        ramp(this.monitor, s.monitor ? 0.07 / masterRms : 0);
      }
    }
    if (routeChanged) this.resetIntegrators();
  }

  private resetIntegrators() {
    this.seeded = false;
    this.zFast = 0;
    this.aFast = 0;
    this.cFast = 0;
    this.zSlow = 0;
    this.aSlow = 0;
    this.cSlow = 0;
    this.leqFast.clear();
    this.leqSlow.clear();
    this.leqAcc = 0;
    this.trendWrite = 0;
    this.trendHead = 0;
    this.trendCount = 0;
    this.lastFallback = 0;
    this.readout.fast = Number.NaN;
    this.readout.slow = Number.NaN;
    this.readout.leq1 = Number.NaN;
    this.readout.leq10 = Number.NaN;
    this.readout.cpeak = Number.NaN;
    this.readout.crest = Number.NaN;
    this.readout.kurtosis = Number.NaN;
    this.readout.lmax = Number.NaN;
    this.readout.diagnosis = null;
    this.lastShift = 0;
  }

  private zeroGains() {
    this.calGain && (this.calGain.gain.value = 0);
    this.oscGain && (this.oscGain.gain.value = 0);
    this.micGain && (this.micGain.gain.value = 0);
    this.monitor && (this.monitor.gain.value = 0);
  }

  private async ensure() {
    if (this.ctx) {
      await this.ctx.resume();
      return;
    }
    if (this.starting) return this.starting;
    this.starting = this.build();
    try {
      await this.starting;
    } finally {
      this.starting = null;
    }
  }

  private async build() {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    this.ctx = ctx;
    this.sampleRate = ctx.sampleRate;
    await ctx.resume();

    const master = ctx.createGain();
    master.gain.value = 1;
    this.master = master;

    const calGain = ctx.createGain();
    calGain.gain.value = 0;
    this.calGain = calGain;
    const oscGain = ctx.createGain();
    oscGain.gain.value = 0;
    this.oscGain = oscGain;
    const micGain = ctx.createGain();
    micGain.gain.value = 0;
    this.micGain = micGain;
    calGain.connect(master);
    oscGain.connect(master);
    micGain.connect(master);

    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = 1000;
    osc.connect(oscGain);
    osc.start();
    this.osc = osc;

    const analyser = ctx.createAnalyser();
    analyser.fftSize = this.fftSize;
    analyser.smoothingTimeConstant = 0.62;
    analyser.minDecibels = -120;
    analyser.maxDecibels = 0;
    master.connect(analyser);
    this.analyser = analyser;

    const mute = ctx.createGain();
    mute.gain.value = 0;
    analyser.connect(mute);

    const monitor = ctx.createGain();
    monitor.gain.value = 0;
    master.connect(monitor);
    monitor.connect(ctx.destination);
    this.monitor = monitor;
    mute.connect(ctx.destination);

    this.attachLevelAnalysers(ctx, master);
    try {
      const blob = new Blob([WORKLET_SOURCE], { type: "application/javascript" });
      const url = URL.createObjectURL(blob);
      await ctx.audioWorklet.addModule(url);
      URL.revokeObjectURL(url);
      this.attachWorklet(ctx, master);
      this.readout.meter = "worklet";
    } catch {
      this.readout.meter = "analyser";
    }

    this.ensureBuffers();
    this.raf = requestAnimationFrame(this.loop);
  }

  private attachLevelAnalysers(ctx: AudioContext, master: GainNode) {
    const make = () => {
      const node = ctx.createAnalyser();
      node.fftSize = 2048;
      node.smoothingTimeConstant = 0;
      return node;
    };
    const chain = (sections: { ff: number[]; fb: number[] }[]) => {
      let node: AudioNode = master;
      for (const section of sections) {
        const iir = ctx.createIIRFilter(section.ff, section.fb);
        node.connect(iir);
        node = iir;
      }
      return node;
    };
    this.analyserA = make();
    this.analyserC = make();
    chain(designAWeighting(ctx.sampleRate)).connect(this.analyserA);
    chain(designCWeighting(ctx.sampleRate)).connect(this.analyserC);
    const mute = ctx.createGain();
    mute.gain.value = 0;
    this.analyserA.connect(mute);
    this.analyserC.connect(mute);
    mute.connect(ctx.destination);
  }

  private attachWorklet(ctx: AudioContext, master: GainNode) {
    const synth = new AudioWorkletNode(ctx, "pump-synth", {
      numberOfInputs: 0,
      numberOfOutputs: 1,
      outputChannelCount: [1],
    });
    synth.connect(this.calGain!);
    this.synth = synth;

    const meter = new AudioWorkletNode(ctx, "pump-meter", {
      numberOfInputs: 3,
      numberOfOutputs: 1,
      outputChannelCount: [1],
    });
    this.meter = meter;
    meter.port.onmessage = (ev: MessageEvent<MeterMsg>) => {
      this.sawMeter = true;
      this.readout.meter = "worklet";
      this.consume(ev.data);
    };
    master.connect(meter, 0, 0);
    let a: AudioNode = master;
    for (const section of designAWeighting(ctx.sampleRate)) {
      const iir = ctx.createIIRFilter(section.ff, section.fb);
      a.connect(iir);
      a = iir;
    }
    a.connect(meter, 0, 1);
    let c: AudioNode = master;
    for (const section of designCWeighting(ctx.sampleRate)) {
      const iir = ctx.createIIRFilter(section.ff, section.fb);
      c.connect(iir);
      c = iir;
    }
    c.connect(meter, 0, 2);
    const mute = ctx.createGain();
    mute.gain.value = 0;
    meter.connect(mute);
    mute.connect(ctx.destination);
  }

  private async ensureMic() {
    if (this.micNode || !this.ctx || !this.micGain) return;
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error("no-mic");
    }
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: false,
        noiseSuppression: false,
        autoGainControl: false,
        channelCount: 1,
      },
      video: false,
    });
    this.micStream = stream;
    this.micNode = this.ctx.createMediaStreamSource(stream);
    this.micNode.connect(this.micGain);
  }

  private releaseMic() {
    this.micNode?.disconnect();
    this.micNode = null;
    this.micStream?.getTracks().forEach((track) => track.stop());
    this.micStream = null;
  }

  private ensureBuffers() {
    if (!this.analyser) return;
    const n = this.analyser.frequencyBinCount;
    if (this.freqDb.length === n) return;
    this.freqDb = new Float32Array(n);
    this.displayDb = new Float32Array(n);
    this.weighted = new Float32Array(n);
    this.peakDb = new Float32Array(n);
    this.peakDb.fill(-160);
    this.fftSize = this.analyser.fftSize;
    this.timeZ = new Float32Array(this.analyser.fftSize);
    this.timeA = new Float32Array(this.analyserA?.fftSize ?? 2048);
    this.timeC = new Float32Array(this.analyserC?.fftSize ?? 2048);
  }

  private loop = () => {
    this.analyse();
    this.raf = requestAnimationFrame(this.loop);
  };

  private analyse() {
    if (!this.running || this.frozen || !this.analyser || !this.ctx) return;
    this.ensureBuffers();
    this.sampleRate = this.ctx.sampleRate;
    if (!this.sawMeter) {
      this.readout.meter = "analyser";
      this.fallbackMeter();
    }
    this.analyser.getFloatFrequencyData(this.freqDb);
    const settings = useSettings.getState();
    const weighting = settings.weighting;
    const spl = settings.splAt0;
    const key = `${weighting}|${this.sampleRate}|${this.fftSize}`;
    if (key !== this.weightKey) {
      this.weights = new Float32Array(this.freqDb.length);
      for (let i = 0; i < this.weights.length; i++) {
        const f = (i * this.sampleRate) / this.fftSize;
        this.weights[i] = i === 0 ? 0 : weightDb(weighting, f);
      }
      this.weightKey = key;
      this.peakDb.fill(-160);
      this.trendCount = 0;
      this.trendHead = 0;
    }
    const n = this.freqDb.length;
    let power = 0;
    for (let i = 1; i < n; i++) {
      let d = this.freqDb[i] ?? -140;
      if (!Number.isFinite(d)) d = -140;
      const w = this.weights[i] ?? 0;
      const v = d + w;
      this.weighted[i] = v;
      power += Math.pow(10, v / 10);
    }
    const fast = this.heroFast(weighting);
    let shift = this.lastShift;
    if (Number.isFinite(fast) && power > 0) {
      const sumDb = 10 * Math.log10(power);
      const meterDbfs = fast - spl;
      const next = meterDbfs - sumDb;
      if (Number.isFinite(next) && next < 60 && next > -60) shift = next;
    }
    this.lastShift = shift;
    const hold = settings.peakHold;
    for (let i = 0; i < n; i++) {
      const splDb = (i === 0 ? -160 : (this.weighted[i] ?? -140) + shift) + spl;
      this.displayDb[i] = splDb;
      if (hold && splDb > (this.peakDb[i] ?? -160)) this.peakDb[i] = splDb;
    }
    const now = performance.now();
    if (now - this.lastRow > 48) {
      this.lastRow = now;
      this.pushWaterfall();
    }
    this.updateOctave(fast);
    if (now - this.lastFeat > 180) {
      this.lastFeat = now;
      this.updateFeatures(settings.rpm, settings.blades);
    }
    this.readout.weighting = weighting;
    this.readout.splAt0 = spl;
    this.readout.source = settings.source;
  }

  private heroFast(weighting: Weighting) {
    if (weighting === "C") return this.levelFrom(this.cFast);
    if (weighting === "Z") return this.levelFrom(this.zFast);
    return this.levelFrom(this.aFast);
  }

  private heroSlow(weighting: Weighting) {
    if (weighting === "C") return this.levelFrom(this.cSlow);
    if (weighting === "Z") return this.levelFrom(this.zSlow);
    return this.levelFrom(this.aSlow);
  }

  private levelFrom(ms: number) {
    return dbOf(ms, useSettings.getState().splAt0);
  }

  private fallbackMeter() {
    if (!this.analyser || !this.analyserA || !this.analyserC) return;
    this.analyser.getFloatTimeDomainData(this.timeZ);
    this.analyserA.getFloatTimeDomainData(this.timeA);
    this.analyserC.getFloatTimeDomainData(this.timeC);
    const pack = (buf: Float32Array) => {
      let s2 = 0;
      let s4 = 0;
      let pk = 0;
      for (let i = 0; i < buf.length; i++) {
        const x = buf[i] ?? 0;
        const x2 = x * x;
        s2 += x2;
        s4 += x2 * x2;
        const ax = Math.abs(x);
        if (ax > pk) pk = ax;
      }
      const n = buf.length || 1;
      return { ms: s2 / n, k: s4 / n, pk };
    };
    const z = pack(this.timeZ);
    const a = pack(this.timeA);
    const c = pack(this.timeC);
    const nowMs = performance.now();
    const dt = this.lastFallback ? Math.min(0.1, (nowMs - this.lastFallback) / 1000) : 0.05;
    this.lastFallback = nowMs;
    this.consume({
      dt,
      zMs: z.ms,
      zK: z.k,
      zPk: z.pk,
      aMs: a.ms,
      cMs: c.ms,
      cPk: c.pk,
    });
  }

  private consume(msg: MeterMsg) {
    if (!this.running || this.frozen) return;
    const dt = Math.max(0.01, msg.dt);
    if (!this.seeded) {
      this.zFast = msg.zMs;
      this.aFast = msg.aMs;
      this.cFast = msg.cMs;
      this.zSlow = msg.zMs;
      this.aSlow = msg.aMs;
      this.cSlow = msg.cMs;
      this.seeded = true;
    } else {
      this.zFast = smooth(this.zFast, msg.zMs, dt, 0.125);
      this.aFast = smooth(this.aFast, msg.aMs, dt, 0.125);
      this.cFast = smooth(this.cFast, msg.cMs, dt, 0.125);
      this.zSlow = smooth(this.zSlow, msg.zMs, dt, 1);
      this.aSlow = smooth(this.aSlow, msg.aMs, dt, 1);
      this.cSlow = smooth(this.cSlow, msg.cMs, dt, 1);
    }
    const weighting = useSettings.getState().weighting;
    const spl = useSettings.getState().splAt0;
    const ms = weighting === "C" ? msg.cMs : weighting === "Z" ? msg.zMs : msg.aMs;
    this.leqAcc += dt;
    if (this.leqAcc >= 0.05) {
      this.leqAcc = 0;
      this.leqFast.push(ms);
      this.leqSlow.push(ms);
    }
    const fast = this.heroFast(weighting);
    const audible = msg.zMs > 1e-10;
    const crest = audible ? msg.zPk / Math.sqrt(msg.zMs) : 0;
    const kurtosis = audible ? msg.zK / (msg.zMs * msg.zMs) : 0;
    this.readout.fast = fast;
    this.readout.slow = this.heroSlow(weighting);
    this.readout.leq1 = this.leqFast.db(spl);
    this.readout.leq10 = this.leqSlow.db(spl);
    this.readout.cpeak = dbOf(msg.cPk * msg.cPk, spl);
    this.readout.crest = crest;
    this.readout.kurtosis = kurtosis;
    this.readout.clipped = msg.zPk > 0.98;
    this.readout.splAt0 = spl;
    this.readout.weighting = weighting;
    if (!Number.isFinite(this.readout.lmax) || fast > this.readout.lmax) {
      this.readout.lmax = fast;
    }
    this.trendWrite += dt;
    if (this.trendWrite >= 0.1) {
      this.trendWrite -= 0.1;
      this.trend[this.trendHead] = fast;
      this.trendHead = (this.trendHead + 1) % this.trend.length;
      if (this.trendCount < this.trend.length) this.trendCount++;
    }
  }

  private pushWaterfall() {
    const cols = this.waterfallCols;
    const db = this.displayDb;
    const sr = this.sampleRate;
    const fft = this.fftSize;
    const n = db.length;
    if (n < 8) return;
    const logMin = Math.log(20);
    const logMax = Math.log(Math.min(20000, sr / 2));
    for (let x = 0; x < cols; x++) {
      const fLo = Math.exp(logMin + (x / cols) * (logMax - logMin));
      const fHi = Math.exp(logMin + ((x + 1) / cols) * (logMax - logMin));
      let i1 = Math.max(1, Math.floor((fLo * fft) / sr));
      let i2 = Math.min(n - 1, Math.ceil((fHi * fft) / sr));
      if (i2 < i1) i2 = i1;
      let m = -200;
      for (let i = i1; i <= i2; i++) {
        const v = db[i] ?? -200;
        if (v > m) m = v;
      }
      this.rowTmp[x] = m;
    }
    this.waterfall.set(this.rowTmp, this.waterfallHead * cols);
    this.waterfallHead = (this.waterfallHead + 1) % this.waterfallRows;
  }

  private updateOctave(fast: number) {
    const bands = synthesizeOctave(this.displayDb, this.sampleRate, this.fftSize);
    if (Number.isFinite(fast)) {
      let p = 0;
      for (let i = 0; i < bands.length; i++) p += Math.pow(10, (bands[i] ?? -140) / 10);
      if (p > 0) {
        const shift = fast - 10 * Math.log10(p);
        if (Number.isFinite(shift) && Math.abs(shift) < 40) {
          for (let i = 0; i < bands.length; i++) bands[i] = (bands[i] ?? -140) + shift;
        }
      }
    }
    if (this.octaveDb.length !== bands.length) this.octaveDb = new Float32Array(bands.length);
    this.octaveDb.set(bands);
  }

  private updateFeatures(rpm: number, blades: number) {
    if (!this.seeded) return;
    const spec = spectralFeatures(this.freqDb, this.sampleRate, this.fftSize, rpm, blades);
    this.readout.dominantHz = spec.dominantHz;
    this.readout.flatness = spec.flatness;
    this.readout.hfRatio = spec.hfRatio;
    this.readout.diagnosis = diagnose({
      ...spec,
      level: this.readout.fast,
      crest: this.readout.crest,
      kurtosis: this.readout.kurtosis,
    });
  }
}

function micMessage(err: unknown) {
  const name = err instanceof DOMException ? err.name : err instanceof Error ? err.message : "";
  if (name === "no-mic") return "这个环境没有麦克风，请用演示声源。";
  if (name === "NotAllowedError" || name === "SecurityError") {
    return "没有麦克风权限。可以继续听演示声源，或在浏览器里允许麦克风。";
  }
  if (name === "NotFoundError") return "没有找到麦克风。";
  return "麦克风没有打开，已回到演示声源。";
}

type Slot = { engine: Engine };
const slot = globalThis as typeof globalThis & { __pumpEngine?: Slot };

slot.__pumpEngine?.engine.dispose();
export const engine = new Engine();
slot.__pumpEngine = { engine };

export function downloadCsv() {
  const s = useSettings.getState();
  const r = engine.readout;
  const lines = [
    "项目,数值",
    `计权,${r.weighting}`,
    `快挡,${num(r.fast)}`,
    `慢挡,${num(r.slow)}`,
    `等效1秒,${num(r.leq1)}`,
    `等效10秒,${num(r.leq10)}`,
    `C峰值,${num(r.cpeak)}`,
    `主频Hz,${num(r.dominantHz)}`,
    `峭度,${num(r.kurtosis)}`,
    `波峰因数,${num(r.crest)}`,
    `转速,${s.rpm}`,
    `叶片,${s.blades}`,
    `判读,${r.diagnosis?.title ?? ""}`,
    "",
    "频率Hz,声级dB",
  ];
  const n = engine.displayDb.length;
  const step = Math.max(1, Math.floor(n / 600));
  for (let i = 1; i < n; i += step) {
    const f = (i * engine.sampleRate) / engine.fftSize;
    lines.push(`${f.toFixed(2)},${(engine.displayDb[i] ?? 0).toFixed(2)}`);
  }
  lines.push("", "倍频程Hz,声级dB");
  for (let i = 0; i < THIRD_OCTAVE.length; i++) {
    lines.push(`${THIRD_OCTAVE[i]!.fc},${(engine.octaveDb[i] ?? 0).toFixed(2)}`);
  }
  const blob = new Blob(["\uFEFF" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "泵声观测.csv";
  a.click();
  URL.revokeObjectURL(a.href);
}

function num(n: number) {
  return Number.isFinite(n) ? n.toFixed(2) : "";
}
