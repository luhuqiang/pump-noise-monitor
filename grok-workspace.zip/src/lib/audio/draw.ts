import { clamp } from "@/lib/utils";

export type Palette = {
  bg: string;
  fg: string;
  muted: string;
  line: string;
  amber: string;
  signal: string;
  alarm: string;
};

let cached: Palette | null = null;

export function palette(): Palette {
  if (cached) return cached;
  const cs = getComputedStyle(document.documentElement);
  const pick = (name: string, fallback: string) => cs.getPropertyValue(name).trim() || fallback;
  cached = {
    bg: pick("--color-bg", "#0b0f12"),
    fg: pick("--color-fg", "#e7eee9"),
    muted: pick("--color-muted", "#93a09a"),
    line: pick("--color-line", "#2c3840"),
    amber: pick("--color-amber", "#e6a23c"),
    signal: pick("--color-signal", "#3dbea5"),
    alarm: pick("--color-alarm", "#e25b4a"),
  };
  return cached;
}

export function resizeCanvas(canvas: HTMLCanvasElement) {
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const rect = canvas.getBoundingClientRect();
  const cssW = Math.max(1, rect.width);
  const cssH = Math.max(1, rect.height);
  const bw = Math.max(1, Math.round(cssW * dpr));
  const bh = Math.max(1, Math.round(cssH * dpr));
  if (canvas.width !== bw || canvas.height !== bh) {
    canvas.width = bw;
    canvas.height = bh;
  }
  return { dpr, cssW, cssH, bw, bh };
}

const F_MIN = 20;

function fMax(sampleRate: number) {
  return Math.min(20000, Math.max(1000, sampleRate / 2));
}

export function freqToX(freq: number, plotW: number, sampleRate: number) {
  const min = Math.log(F_MIN);
  const max = Math.log(fMax(sampleRate));
  const f = clamp(freq, F_MIN, fMax(sampleRate));
  return ((Math.log(f) - min) / (max - min)) * plotW;
}

export function xToFreq(x: number, plotW: number, sampleRate: number) {
  const min = Math.log(F_MIN);
  const max = Math.log(fMax(sampleRate));
  const t = clamp(x / Math.max(1, plotW), 0, 1);
  return Math.exp(min + t * (max - min));
}

function dbToY(db: number, plotH: number, splAt0: number) {
  const t = (db - (splAt0 - 100)) / 100;
  return plotH - clamp(t, 0, 1) * plotH;
}

const HEAT = new Uint8ClampedArray(256 * 3);
const STOPS: [number, number, number, number][] = [
  [0, 11, 15, 18],
  [0.2, 14, 72, 68],
  [0.48, 61, 190, 165],
  [0.76, 230, 162, 60],
  [1, 247, 240, 226],
];
for (let i = 0; i < 256; i++) {
  const t = i / 255;
  let j = 0;
  while (j < STOPS.length - 2 && t > STOPS[j + 1]![0]) j++;
  const a = STOPS[j]!;
  const b = STOPS[j + 1]!;
  const u = (t - a[0]) / (b[0] - a[0] || 1);
  HEAT[i * 3] = Math.round(a[1] + (b[1] - a[1]) * u);
  HEAT[i * 3 + 1] = Math.round(a[2] + (b[2] - a[2]) * u);
  HEAT[i * 3 + 2] = Math.round(a[3] + (b[3] - a[3]) * u);
}

function heatIndex(db: number, splAt0: number) {
  const t = (db - (splAt0 - 100)) / 100;
  return clamp(Math.round(t * 255), 0, 255);
}

const SPEC = { l: 46, r: 8, t: 10, b: 22 };

export function drawSpectrum(
  canvas: HTMLCanvasElement,
  db: Float32Array,
  peak: Float32Array | null,
  sampleRate: number,
  fftSize: number,
  splAt0: number,
  rpm: number,
  blades: number,
  cursorFrac: number | null,
) {
  const { dpr, cssW, cssH } = resizeCanvas(canvas);
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  const pal = palette();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = pal.bg;
  ctx.fillRect(0, 0, cssW, cssH);
  const plotW = cssW - SPEC.l - SPEC.r;
  const plotH = cssH - SPEC.t - SPEC.b;
  ctx.font = "11px 'IBM Plex Mono', ui-monospace, monospace";
  ctx.lineWidth = 1;
  ctx.strokeStyle = pal.line;
  ctx.fillStyle = pal.muted;
  ctx.textAlign = "right";
  ctx.textBaseline = "middle";
  for (let dbTick = 0; dbTick <= 100; dbTick += 20) {
    const y = SPEC.t + dbToY(splAt0 - dbTick, plotH, splAt0);
    ctx.beginPath();
    ctx.moveTo(SPEC.l, y);
    ctx.lineTo(SPEC.l + plotW, y);
    ctx.stroke();
    ctx.fillText(String(Math.round(splAt0 - dbTick)), SPEC.l - 6, y);
  }
  ctx.textAlign = "center";
  ctx.textBaseline = "top";
  for (const freq of [20, 100, 1000, 10000]) {
    if (freq >= fMax(sampleRate)) continue;
    const x = SPEC.l + freqToX(freq, plotW, sampleRate);
    ctx.beginPath();
    ctx.moveTo(x, SPEC.t);
    ctx.lineTo(x, SPEC.t + plotH);
    ctx.stroke();
    ctx.fillText(freq >= 1000 ? `${freq / 1000}k` : String(freq), x, SPEC.t + plotH + 6);
  }

  let hover: { hz: number; db: number } | null = null;
  if (db.length > 8 && plotW > 8) {
    const cols: number[] = new Array(Math.ceil(plotW));
    const n = db.length;
    for (let x = 0; x < cols.length; x++) {
      const fLo = xToFreq(x, plotW, sampleRate);
      const fHi = xToFreq(x + 1, plotW, sampleRate);
      let i1 = Math.max(1, Math.floor((fLo * fftSize) / sampleRate));
      let i2 = Math.min(n - 1, Math.ceil((fHi * fftSize) / sampleRate));
      if (i2 < i1) i2 = i1;
      let m = -200;
      for (let i = i1; i <= i2; i++) {
        const v = db[i] ?? -200;
        if (v > m) m = v;
      }
      cols[x] = m;
    }
    ctx.beginPath();
    cols.forEach((v, x) => {
      const y = SPEC.t + dbToY(v, plotH, splAt0);
      if (x === 0) ctx.moveTo(SPEC.l + x, y);
      else ctx.lineTo(SPEC.l + x, y);
    });
    ctx.lineTo(SPEC.l + cols.length, SPEC.t + plotH);
    ctx.lineTo(SPEC.l, SPEC.t + plotH);
    ctx.closePath();
    ctx.fillStyle = withAlpha(pal.signal, 0.16);
    ctx.fill();
    ctx.beginPath();
    cols.forEach((v, x) => {
      const y = SPEC.t + dbToY(v, plotH, splAt0);
      if (x === 0) ctx.moveTo(SPEC.l + x, y);
      else ctx.lineTo(SPEC.l + x, y);
    });
    ctx.strokeStyle = pal.signal;
    ctx.lineWidth = 1.5;
    ctx.stroke();

    if (peak && peak.length === db.length) {
      ctx.beginPath();
      let started = false;
      for (let x = 0; x < cols.length; x++) {
        const fLo = xToFreq(x, plotW, sampleRate);
        const fHi = xToFreq(x + 1, plotW, sampleRate);
        let i1 = Math.max(1, Math.floor((fLo * fftSize) / sampleRate));
        let i2 = Math.min(n - 1, Math.ceil((fHi * fftSize) / sampleRate));
        if (i2 < i1) i2 = i1;
        let m = -200;
        for (let i = i1; i <= i2; i++) {
          const v = peak[i] ?? -200;
          if (v > m) m = v;
        }
        const y = SPEC.t + dbToY(m, plotH, splAt0);
        if (!started) {
          ctx.moveTo(SPEC.l + x, y);
          started = true;
        } else ctx.lineTo(SPEC.l + x, y);
      }
      ctx.strokeStyle = pal.amber;
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    if (rpm >= 300) {
      mark(ctx, pal.amber, SPEC.l + freqToX(rpm / 60, plotW, sampleRate), SPEC.t, plotH, "1×");
      const bpf = (rpm / 60) * blades;
      if (bpf < fMax(sampleRate)) {
        mark(ctx, pal.fg, SPEC.l + freqToX(bpf, plotW, sampleRate), SPEC.t, plotH, "BPF");
      }
    }

    if (cursorFrac !== null) {
      const x = clamp(cursorFrac * cssW, SPEC.l, SPEC.l + plotW) - SPEC.l;
      const col = clamp(Math.round(x), 0, cols.length - 1);
      const hz = xToFreq(col, plotW, sampleRate);
      const level = cols[col] ?? Number.NaN;
      hover = { hz, db: level };
      ctx.strokeStyle = pal.fg;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(SPEC.l + col, SPEC.t);
      ctx.lineTo(SPEC.l + col, SPEC.t + plotH);
      ctx.stroke();
    }
  } else {
    ctx.fillStyle = pal.muted;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = "13px 'IBM Plex Sans', sans-serif";
    ctx.fillText("开始观测后显示频谱", SPEC.l + plotW / 2, SPEC.t + plotH / 2);
  }
  return hover;
}

function mark(
  ctx: CanvasRenderingContext2D,
  color: string,
  x: number,
  top: number,
  plotH: number,
  label: string,
) {
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  ctx.setLineDash([3, 3]);
  ctx.beginPath();
  ctx.moveTo(x, top);
  ctx.lineTo(x, top + plotH);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = color;
  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  ctx.fillText(label, x + 4, top + 4);
}

const images = new WeakMap<HTMLCanvasElement, ImageData>();

export function drawWaterfall(
  canvas: HTMLCanvasElement,
  data: Float32Array,
  cols: number,
  rows: number,
  head: number,
  splAt0: number,
  active: boolean,
) {
  const { bw, bh } = resizeCanvas(canvas);
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  let img = images.get(canvas);
  if (!img || img.width !== bw || img.height !== bh) {
    img = ctx.createImageData(bw, bh);
    images.set(canvas, img);
  }
  const px = img.data;
  let seen = false;
  for (let y = 0; y < bh; y++) {
    const rowIndex = Math.min(rows - 1, Math.floor((y / bh) * rows));
    const src = (head - 1 - rowIndex + rows * 4) % rows;
    const base = src * cols;
    for (let x = 0; x < bw; x++) {
      const col = Math.min(cols - 1, Math.floor((x / bw) * cols));
      const db = data[base + col] ?? -200;
      if (db > -120) seen = true;
      const hi = heatIndex(db, splAt0) * 3;
      const o = (y * bw + x) * 4;
      px[o] = HEAT[hi] ?? 0;
      px[o + 1] = HEAT[hi + 1] ?? 0;
      px[o + 2] = HEAT[hi + 2] ?? 0;
      px[o + 3] = 255;
    }
  }
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.putImageData(img, 0, 0);
  if (!seen) {
    const pal = palette();
    const { dpr, cssW, cssH } = resizeCanvas(canvas);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = pal.muted;
    ctx.font = "13px 'IBM Plex Sans', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(active ? "正在积累瀑布…" : "瀑布图等待采样", cssW / 2, cssH / 2);
  }
}

export function drawTrend(
  canvas: HTMLCanvasElement,
  trend: Float32Array,
  head: number,
  count: number,
  splAt0: number,
  warn: number,
  danger: number,
) {
  const { dpr, cssW, cssH } = resizeCanvas(canvas);
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const pal = palette();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = pal.bg;
  ctx.fillRect(0, 0, cssW, cssH);
  const l = 46;
  const r = 8;
  const t = 10;
  const b = 18;
  const plotW = cssW - l - r;
  const plotH = cssH - t - b;
  ctx.font = "11px 'IBM Plex Mono', ui-monospace, monospace";
  ctx.fillStyle = pal.muted;
  ctx.textAlign = "right";
  ctx.textBaseline = "middle";
  ctx.strokeStyle = pal.line;
  ctx.lineWidth = 1;
  for (const dbTick of [0, 50, 100]) {
    const y = t + dbToY(splAt0 - dbTick, plotH, splAt0);
    ctx.beginPath();
    ctx.moveTo(l, y);
    ctx.lineTo(l + plotW, y);
    ctx.stroke();
    ctx.fillText(String(Math.round(splAt0 - dbTick)), l - 6, y);
  }
  rule(ctx, pal.amber, l, plotW, t, plotH, splAt0, warn);
  rule(ctx, pal.alarm, l, plotW, t, plotH, splAt0, danger);
  if (count < 2) {
    ctx.fillStyle = pal.muted;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = "13px 'IBM Plex Sans', sans-serif";
    ctx.fillText("采样后画出 60 秒曲线", l + plotW / 2, t + plotH / 2);
    return;
  }
  ctx.beginPath();
  ctx.strokeStyle = pal.signal;
  ctx.lineWidth = 1.5;
  for (let i = 0; i < count; i++) {
    const idx = (head - count + i + trend.length) % trend.length;
    const v = trend[idx] ?? splAt0 - 100;
    const x = l + (i / Math.max(1, count - 1)) * plotW;
    const y = t + dbToY(v, plotH, splAt0);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();
  ctx.fillStyle = pal.muted;
  ctx.textAlign = "left";
  ctx.textBaseline = "top";
  ctx.font = "11px 'IBM Plex Mono', ui-monospace, monospace";
  ctx.fillText("60 秒前", l, t + plotH + 4);
  ctx.textAlign = "right";
  ctx.fillText("现在", l + plotW, t + plotH + 4);
}

function rule(
  ctx: CanvasRenderingContext2D,
  color: string,
  l: number,
  plotW: number,
  t: number,
  plotH: number,
  splAt0: number,
  db: number,
) {
  const y = t + dbToY(db, plotH, splAt0);
  ctx.strokeStyle = color;
  ctx.setLineDash([4, 4]);
  ctx.beginPath();
  ctx.moveTo(l, y);
  ctx.lineTo(l + plotW, y);
  ctx.stroke();
  ctx.setLineDash([]);
}

function withAlpha(color: string, alpha: number) {
  const hex = color.trim();
  const m = /^#([\da-f]{6})$/i.exec(hex);
  if (!m) return color;
  const n = parseInt(m[1]!, 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
