import type { SpectralFeatures } from "./features.ts";

export type DiagnosisId =
  | "silence"
  | "ref"
  | "bearing"
  | "cavitation"
  | "looseness"
  | "imbalance"
  | "healthy"
  | "mixed";

export type Diagnosis = {
  id: DiagnosisId;
  title: string;
  summary: string;
  confidence: "低" | "中" | "高";
  evidence: string[];
};

export type DiagnoseInput = SpectralFeatures & {
  level: number;
  crest: number;
  kurtosis: number;
};

function evidence(f: DiagnoseInput): string[] {
  return [
    `平坦度 ${f.flatness.toFixed(2)}`,
    `高频比 ${f.hfRatio.toFixed(2)}`,
    `峭度 ${f.kurtosis.toFixed(1)}`,
    `波峰因数 ${f.crest.toFixed(2)}`,
    `1×/叶片 ${f.oneXRatio.toFixed(2)}`,
    `半阶次 ${f.halfRatio.toFixed(2)}`,
  ];
}

export function diagnose(f: DiagnoseInput): Diagnosis {
  const ev = evidence(f);
  if (!Number.isFinite(f.level) || f.level < 40) {
    return {
      id: "silence",
      title: "信号太弱",
      summary: "电平不够，故障线索没有意义。靠近泵体，或先打开演示声源确认仪表在工作。",
      confidence: "低",
      evidence: ev,
    };
  }
  if (Math.abs(f.dominantHz - 1000) < 20 && f.flatness < 0.25 && f.crest < 2.2 && f.kurtosis < 3.5) {
    return {
      id: "ref",
      title: "1 kHz 正弦",
      summary: "几乎只有一根谱线。A、C、Z 三种计权在 1 kHz 上应当重合，用来核对这台仪表，不是泵的声音。",
      confidence: "高",
      evidence: ev,
    };
  }
  if (f.kurtosis >= 6 && f.crest >= 2.8) {
    return {
      id: "bearing",
      title: "疑似轴承冲击",
      summary:
        "峭度和波峰因数一起升高，声压里有重复冲击，不只是平稳的叶片音。轴承损伤会这样，防护罩碰磨也会。对照润滑和振动峭度再下判断。",
      confidence: f.kurtosis >= 10 ? "高" : "中",
      evidence: ev,
    };
  }
  if (f.hfRatio >= 0.9 && f.flatness >= 0.22) {
    return {
      id: "cavitation",
      title: "疑似汽蚀",
      summary:
        "2–8 kHz 相对低频抬起来了，频谱更像宽带噪声，而不是清楚的叶片音。现场常见于汽蚀、进口不畅或强湍流。核对流量、进口压力和安装汽蚀余量。",
      confidence: f.hfRatio >= 2 && f.flatness >= 0.12 ? "高" : "中",
      evidence: ev,
    };
  }
  if (f.halfRatio >= 0.45 && f.harmonicCount >= 4) {
    return {
      id: "looseness",
      title: "疑似机械松动",
      summary:
        "0.5×、1.5× 这类半阶次明显，整数谐波也铺得很开。地脚、轴承座或联轴器松动时常是这种空气声。",
      confidence: f.halfRatio >= 0.8 ? "高" : "中",
      evidence: ev,
    };
  }
  if (f.oneXRatio >= 2.4 && f.hfRatio < 1.2 && f.flatness < 0.2) {
    return {
      id: "imbalance",
      title: "疑似叶轮不平衡",
      summary:
        "1 倍转频明显高于叶片通过频率。空气声里的转频突出，要和不平衡、偏心或对中不良一起看，最好对照振动里的 1×。",
      confidence: f.oneXRatio >= 4 ? "高" : "中",
      evidence: ev,
    };
  }
  if (f.bpfRatio >= 1.3 && f.hfRatio < 0.7 && f.kurtosis < 6 && f.halfRatio < 0.35) {
    return {
      id: "healthy",
      title: "运转平稳",
      summary:
        "能量集中在叶片通过频率附近，转频不强，高频本底和峭度都低。这组形态接近平稳运行的离心泵。",
      confidence: f.bpfRatio >= 2 ? "高" : "中",
      evidence: ev,
    };
  }
  return {
    id: "mixed",
    title: "特征不明显",
    summary:
      "几项指标没有同时指向同一种典型故障。换一个听音位置，确认转速和叶片数，或和振动测量对照。",
    confidence: "低",
    evidence: ev,
  };
}
