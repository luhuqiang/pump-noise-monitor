export type SpectralFeatures = {
  dominantHz: number;
  flatness: number;
  hfRatio: number;
  oneXRatio: number;
  bpfRatio: number;
  halfRatio: number;
  harmonicCount: number;
};

function dbToPower(db: number) {
  if (!Number.isFinite(db)) return 0;
  return Math.pow(10, Math.max(-140, db) / 10);
}

function powerAround(db: Float32Array, sampleRate: number, fftSize: number, freq: number) {
  if (freq < 12) return 0;
  const center = Math.round((freq * fftSize) / sampleRate);
  const half = Math.max(1, Math.round(center * 0.045));
  let p = 0;
  for (let i = center - half; i <= center + half; i++) {
    if (i < 1 || i >= db.length) continue;
    p += dbToPower(db[i] ?? -140);
  }
  return p;
}

function powerBetween(
  db: Float32Array,
  sampleRate: number,
  fftSize: number,
  f1: number,
  f2: number,
) {
  const i1 = Math.max(1, Math.floor((f1 * fftSize) / sampleRate));
  const i2 = Math.min(db.length - 1, Math.ceil((f2 * fftSize) / sampleRate));
  let p = 0;
  for (let i = i1; i <= i2; i++) p += dbToPower(db[i] ?? -140);
  return p;
}

export function spectralFeatures(
  db: Float32Array,
  sampleRate: number,
  fftSize: number,
  rpm: number,
  blades: number,
): SpectralFeatures {
  const n = db.length;
  let maxI = 2;
  let maxV = -Infinity;
  const minBin = Math.max(2, Math.floor((20 * fftSize) / sampleRate));
  const maxBin = Math.min(n - 2, Math.floor((5000 * fftSize) / sampleRate));
  for (let i = minBin; i <= maxBin; i++) {
    const v = db[i] ?? -140;
    if (v > maxV) {
      maxV = v;
      maxI = i;
    }
  }
  const a = db[maxI - 1] ?? maxV;
  const b = db[maxI] ?? maxV;
  const c = db[maxI + 1] ?? maxV;
  const denom = a - 2 * b + c;
  const delta = denom === 0 ? 0 : 0.5 * (a - c) / denom;
  const dominantHz = Math.max(0, (maxI + delta) * sampleRate / fftSize);

  let logSum = 0;
  let sum = 0;
  let count = 0;
  const iLo = Math.max(1, Math.floor((200 * fftSize) / sampleRate));
  const iHi = Math.min(n - 1, Math.floor((8000 * fftSize) / sampleRate));
  for (let i = iLo; i <= iHi; i++) {
    const mag = Math.pow(10, Math.max(-140, db[i] ?? -140) / 20);
    sum += mag;
    logSum += Math.log(mag + 1e-16);
    count++;
  }
  const flatness = count > 0 && sum > 0 ? Math.exp(logSum / count) / (sum / count) : 0;

  const hf = powerBetween(db, sampleRate, fftSize, 2000, 8000);
  const lf = powerBetween(db, sampleRate, fftSize, 40, 500);
  const hfRatio = hf / Math.max(lf, 1e-18);

  const f0 = rpm > 0 ? rpm / 60 : 0;
  let oneXRatio = 0;
  let bpfRatio = 0;
  let halfRatio = 0;
  let harmonicCount = 0;
  if (f0 >= 15) {
    const p1 = powerAround(db, sampleRate, fftSize, f0);
    const bpf = powerAround(db, sampleRate, fftSize, f0 * Math.max(2, blades));
    oneXRatio = p1 / Math.max(bpf, 1e-18);
    bpfRatio = bpf / Math.max(p1, 1e-18);
    let halfP = 0;
    let intP = 0;
    let loudest = 0;
    const harms: number[] = [];
    for (let h = 1; h <= 10; h++) {
      const p = powerAround(db, sampleRate, fftSize, f0 * h);
      harms.push(p);
      if (p > loudest) loudest = p;
      if (h <= 4) intP += p;
    }
    halfP += powerAround(db, sampleRate, fftSize, f0 * 0.5);
    halfP += powerAround(db, sampleRate, fftSize, f0 * 1.5);
    halfP += powerAround(db, sampleRate, fftSize, f0 * 2.5);
    halfP += powerAround(db, sampleRate, fftSize, f0 * 3.5);
    halfRatio = halfP / Math.max(intP, 1e-18);
    const gate = loudest * Math.pow(10, -12 / 10);
    harmonicCount = harms.filter((p) => p >= gate && p > 0).length;
    if (intP < 1e-12) {
      oneXRatio = 0;
      bpfRatio = 0;
      halfRatio = 0;
    }
  }

  return {
    dominantHz,
    flatness,
    hfRatio: Math.min(hfRatio, 99),
    oneXRatio: Math.min(oneXRatio, 99),
    bpfRatio: Math.min(bpfRatio, 99),
    halfRatio: Math.min(halfRatio, 99),
    harmonicCount,
  };
}
