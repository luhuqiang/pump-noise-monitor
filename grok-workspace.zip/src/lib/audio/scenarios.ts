export const REF_DBFS = -36;

export const SCENARIOS = [
  {
    id: "healthy",
    mode: 0,
    name: "健康离心泵",
    rpm: 2950,
    blades: 6,
    targetDb: 76,
    blurb: "叶片通过频率清楚，高频本底低。名义声级按 0 dBFS = 120 dB 制作。",
  },
  {
    id: "cavitation",
    mode: 1,
    name: "汽蚀",
    rpm: 2950,
    blades: 6,
    targetDb: 97,
    blurb: "同样的叶片音被 2 kHz 以上的宽带噪声盖住，声级也抬高。",
  },
  {
    id: "imbalance",
    mode: 2,
    name: "叶轮不平衡",
    rpm: 2950,
    blades: 6,
    targetDb: 83,
    blurb: "1 倍转频被加重。可改转速，看这根谱线跟着动。",
  },
  {
    id: "looseness",
    mode: 3,
    name: "机械松动",
    rpm: 2950,
    blades: 6,
    targetDb: 88,
    blurb: "半阶次和一长串转频谐波。名义声级会越过警告线。",
  },
  {
    id: "bearing",
    mode: 4,
    name: "轴承冲击",
    rpm: 2950,
    blades: 6,
    targetDb: 80,
    blurb: "重复冲击把峭度和波峰因数拉高，总声级不一定很大。",
  },
] as const;

export type ScenarioId = (typeof SCENARIOS)[number]["id"];

export function getScenario(id: ScenarioId) {
  return SCENARIOS.find((s) => s.id === id) ?? SCENARIOS[0];
}
