import { create } from "zustand";
import { getScenario, type ScenarioId } from "@/lib/audio/scenarios";

export type Weighting = "A" | "C" | "Z";
export type SourceMode = "demo" | "mic" | "ref";

export type Alarm = { at: string; db: number; note: string };

type Data = {
  source: SourceMode;
  scenario: ScenarioId;
  rpm: number;
  blades: number;
  weighting: Weighting;
  splAt0: number;
  warn: number;
  danger: number;
  peakHold: boolean;
  monitor: boolean;
  alarms: Alarm[];
};

type Settings = Data & {
  loaded: boolean;
  load: () => void;
  update: (partial: Partial<Data>) => void;
  selectScenario: (id: ScenarioId) => void;
  pushAlarm: (alarm: Alarm) => void;
  clearAlarms: () => void;
};

const KEY = "pump-acoustic-settings-v1";

const DEFAULTS: Data = {
  source: "demo",
  scenario: "healthy",
  rpm: 2950,
  blades: 6,
  weighting: "A",
  splAt0: 120,
  warn: 85,
  danger: 95,
  peakHold: true,
  monitor: true,
  alarms: [],
};

function persist(data: Data) {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    /* private mode */
  }
}

function snapshot(s: Settings): Data {
  return {
    source: s.source,
    scenario: s.scenario,
    rpm: s.rpm,
    blades: s.blades,
    weighting: s.weighting,
    splAt0: s.splAt0,
    warn: s.warn,
    danger: s.danger,
    peakHold: s.peakHold,
    monitor: s.monitor,
    alarms: s.alarms,
  };
}

export const useSettings = create<Settings>((set, get) => ({
  ...DEFAULTS,
  loaded: false,
  load: () => {
    if (get().loaded) return;
    let next = DEFAULTS;
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Data>;
        next = { ...DEFAULTS, ...parsed };
        if (!Array.isArray(next.alarms)) next.alarms = [];
      }
    } catch {
      next = DEFAULTS;
    }
    set({ ...next, loaded: true });
  },
  update: (partial) => {
    set(partial);
    if (get().loaded) persist(snapshot(get()));
  },
  selectScenario: (id) => {
    const scenario = getScenario(id);
    set({
      source: "demo",
      scenario: id,
      rpm: scenario.rpm,
      blades: scenario.blades,
    });
    if (get().loaded) persist(snapshot(get()));
  },
  pushAlarm: (alarm) => {
    const alarms = [alarm, ...get().alarms].slice(0, 12);
    set({ alarms });
    if (get().loaded) persist(snapshot(get()));
  },
  clearAlarms: () => {
    set({ alarms: [] });
    if (get().loaded) persist(snapshot(get()));
  },
}));
