import { AudioLines, Mic } from "lucide-react";
import { engine } from "@/lib/audio/engine";
import { getScenario, SCENARIOS } from "@/lib/audio/scenarios";
import { useSettings } from "@/lib/settings";
import { cn } from "@/lib/utils";
import { controlClass, controlOn } from "@/components/panel";

export function Toolbar() {
  const source = useSettings((s) => s.source);
  const scenario = useSettings((s) => s.scenario);
  const selectScenario = useSettings((s) => s.selectScenario);
  const update = useSettings((s) => s.update);
  const current = getScenario(scenario);

  return (
    <div className="min-w-0">
      <div className="flex flex-wrap gap-2">
        {SCENARIOS.map((item) => {
          const on = source === "demo" && scenario === item.id;
          return (
            <button
              key={item.id}
              type="button"
              aria-pressed={on}
              className={cn(controlClass, on && controlOn)}
              onClick={() => {
                selectScenario(item.id);
                void engine.start();
              }}
            >
              {item.name}
            </button>
          );
        })}
        <button
          type="button"
          aria-pressed={source === "mic"}
          className={cn(controlClass, source === "mic" && controlOn)}
          onClick={() => {
            update({ source: "mic" });
            void engine.start();
          }}
        >
          <Mic className="size-4" aria-hidden="true" />
          麦克风
        </button>
        <button
          type="button"
          aria-pressed={source === "ref"}
          className={cn(controlClass, source === "ref" && controlOn)}
          onClick={() => {
            update({ source: "ref" });
            void engine.start();
          }}
        >
          <AudioLines className="size-4" aria-hidden="true" />
          1 kHz 自检
        </button>
      </div>
      <p className="mt-2 text-sm text-muted">
        {source === "mic"
          ? "已请求关闭回声消除、降噪和自动增益。手机增益仍会改变读数，用下方满度声级对齐声级计。"
          : source === "ref"
            ? "1 kHz 正弦，RMS 为 −36 dBFS。A、C、Z 在这个频率上应几乎重合。"
            : current.blurb}
      </p>
    </div>
  );
}
