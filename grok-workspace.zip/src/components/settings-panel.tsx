import { Download, RotateCcw } from "lucide-react";
import { downloadCsv, engine } from "@/lib/audio/engine";
import { useSettings } from "@/lib/settings";
import { clamp, cn } from "@/lib/utils";
import { Panel, controlClass } from "@/components/panel";

export function SettingsPanel() {
  const rpm = useSettings((s) => s.rpm);
  const blades = useSettings((s) => s.blades);
  const splAt0 = useSettings((s) => s.splAt0);
  const warn = useSettings((s) => s.warn);
  const danger = useSettings((s) => s.danger);
  const monitor = useSettings((s) => s.monitor);
  const alarms = useSettings((s) => s.alarms);
  const update = useSettings((s) => s.update);
  const clearAlarms = useSettings((s) => s.clearAlarms);

  return (
    <Panel title="校准、阈值和记录" hint="这些设置只留在这台设备上">
      <div className="grid gap-3 px-2 pb-2 sm:grid-cols-2 lg:grid-cols-3">
        <Field
          label="转速 r/min"
          value={rpm}
          min={300}
          max={6000}
          step={10}
          onChange={(value) => update({ rpm: value })}
        />
        <Field
          label="叶片数"
          value={blades}
          min={2}
          max={12}
          step={1}
          onChange={(value) => update({ blades: value })}
        />
        <Field
          label="0 dBFS 对应 dB"
          value={splAt0}
          min={80}
          max={140}
          step={1}
          onChange={(value) => update({ splAt0: value })}
        />
        <Field
          label="警告 dB"
          value={warn}
          min={40}
          max={130}
          step={1}
          onChange={(value) => update({ warn: Math.min(value, danger - 1) })}
        />
        <Field
          label="危险 dB"
          value={danger}
          min={45}
          max={140}
          step={1}
          onChange={(value) => update({ danger: Math.max(value, warn + 1) })}
        />
        <div className="flex items-end">
          <button
            type="button"
            aria-pressed={monitor}
            className={cn(controlClass, monitor && "bg-amber text-ink")}
            onClick={() => update({ monitor: !monitor })}
          >
            {monitor ? "监听开" : "监听关"}
          </button>
        </div>
      </div>
      <div className="flex flex-wrap gap-2 px-2 pb-2">
        <button type="button" className={controlClass} onClick={() => downloadCsv()}>
          <Download className="size-4" aria-hidden="true" />
          导出频谱
        </button>
        <button type="button" className={controlClass} onClick={() => engine.resetMax()}>
          <RotateCcw className="size-4" aria-hidden="true" />
          清除最大声级
        </button>
        <button type="button" className={controlClass} onClick={() => clearAlarms()} disabled={alarms.length === 0}>
          清除记录
        </button>
      </div>
      <div className="px-2 pb-2">
        {alarms.length === 0 ? (
          <p className="text-sm text-muted">越过危险阈值时记在这里。自检正弦不记。</p>
        ) : (
          <ul className="divide-y divide-line">
            {alarms.map((alarm, index) => (
              <li key={`${alarm.at}-${index}`} className="flex items-center justify-between gap-3 py-2 text-sm">
                <span className="text-muted">{formatWhen(alarm.at)}</span>
                <span className="min-w-0 flex-1 truncate">{alarm.note}</span>
                <span className="font-mono tabular-nums text-alarm">{alarm.db.toFixed(1)} dB</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Panel>
  );
}

function Field({
  label,
  value,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
}) {
  return (
    <label className="block">
      <span className="text-xs text-muted">{label}</span>
      <input
        className="mt-1 h-11 w-full rounded-lg border border-line bg-bg px-3 font-mono text-base text-fg"
        type="number"
        inputMode="decimal"
        min={min}
        max={max}
        step={step}
        value={Number.isFinite(value) ? value : min}
        onChange={(event) => {
          const next = Number(event.target.value);
          if (!Number.isFinite(next)) return;
          onChange(clamp(next, min, max));
        }}
      />
    </label>
  );
}

function formatWhen(iso: string) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleString("zh-CN", {
    hour12: false,
    month: "numeric",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}
