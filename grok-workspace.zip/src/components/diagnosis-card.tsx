import { AlertTriangle, AudioLines, Check, CircleHelp, Gauge, MicOff, Unplug, Waves } from "lucide-react";
import type { DiagnosisId } from "@/lib/audio/diagnose";
import { engine } from "@/lib/audio/engine";
import { cn } from "@/lib/utils";
import { Panel } from "@/components/panel";
import { useFrame } from "@/components/use-frame";

const ICONS: Record<DiagnosisId, typeof Check> = {
  healthy: Check,
  cavitation: Waves,
  imbalance: Gauge,
  looseness: Unplug,
  bearing: AlertTriangle,
  mixed: CircleHelp,
  silence: MicOff,
  ref: AudioLines,
};

const TONE: Record<DiagnosisId, string> = {
  healthy: "text-signal",
  cavitation: "text-alarm",
  bearing: "text-alarm",
  imbalance: "text-amber",
  looseness: "text-amber",
  mixed: "text-fg",
  silence: "text-muted",
  ref: "text-fg",
};

export function DiagnosisCard() {
  const tick = useFrame(200);
  void tick;
  const result = engine.readout.running ? engine.readout.diagnosis : null;
  const Icon = result ? ICONS[result.id] : CircleHelp;

  return (
    <Panel title="工况线索" hint="按当前转速和叶片数核对转频、叶片通过频率和半阶次">
      <div className="px-2 pb-3">
        {result ? (
          <>
            <div className="flex items-center gap-2">
              <Icon className={cn("size-5", TONE[result.id])} aria-hidden="true" />
              <h3 className={cn("text-lg font-medium", TONE[result.id])} data-testid="diagnosis">
                {result.title}
              </h3>
              <span className="font-mono text-xs text-muted">把握 {result.confidence}</span>
            </div>
            <p className="mt-2 text-sm text-fg">{result.summary}</p>
            <ul className="mt-3 flex flex-wrap gap-2">
              {result.evidence.map((item) => (
                <li key={item} className="rounded-md bg-bg px-2 py-1 font-mono text-xs text-muted">
                  {item}
                </li>
              ))}
            </ul>
          </>
        ) : (
          <p className="text-sm text-muted">
            开始观测后，这里会根据谱形给出排查方向：汽蚀看高频宽带，不平衡看 1 倍转频，松动看半阶次，轴承冲击看峭度。演示声源不需要麦克风。
          </p>
        )}
        <p className="mt-3 text-xs text-muted">线索不是故障结论，也不能代替振动检测。</p>
      </div>
    </Panel>
  );
}
