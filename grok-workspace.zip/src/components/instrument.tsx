import { useEffect, useState } from "react";
import { AudioLines, Pause, Play } from "lucide-react";
import { DiagnosisCard } from "@/components/diagnosis-card";
import { MeterCard } from "@/components/meter-card";
import { OctaveView, SpectrumView, TrendView, WaterfallView } from "@/components/charts";
import { controlClass, controlOn } from "@/components/panel";
import { SettingsPanel } from "@/components/settings-panel";
import { Toolbar } from "@/components/toolbar";
import { engine } from "@/lib/audio/engine";
import { useSettings } from "@/lib/settings";
import { cn } from "@/lib/utils";
import { useFrame } from "@/components/use-frame";

export function Instrument() {
  const load = useSettings((s) => s.load);
  const source = useSettings((s) => s.source);
  const scenario = useSettings((s) => s.scenario);
  const rpm = useSettings((s) => s.rpm);
  const blades = useSettings((s) => s.blades);
  const monitor = useSettings((s) => s.monitor);
  const tick = useFrame(250);
  void tick;
  const running = engine.readout.running;
  const frozen = engine.readout.frozen;
  const error = engine.readout.error;
  const [spoken, setSpoken] = useState("尚未开始采样");

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const id = window.setTimeout(() => {
      void engine.sync();
    }, 140);
    return () => window.clearTimeout(id);
  }, [source, scenario, rpm, blades, monitor]);

  useEffect(() => {
    const id = window.setInterval(() => {
      const level = engine.readout;
      if (!level.running || !Number.isFinite(level.fast)) {
        setSpoken("尚未开始采样");
        return;
      }
      setSpoken(
        `当前${level.weighting}计权快挡 ${level.fast.toFixed(0)} 分贝，主频 ${level.dominantHz.toFixed(0)} 赫兹`,
      );
    }, 2000);
    return () => window.clearInterval(id);
  }, []);

  const sourceLabel = source === "mic" ? "麦克风" : source === "ref" ? "1 kHz 自检" : "演示";

  return (
    <main className="mx-auto flex w-full max-w-6xl flex-col gap-3 px-3 py-4 sm:px-5 sm:py-6">
      <p className="sr-only" aria-live="polite">
        {spoken}
      </p>
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex size-11 items-center justify-center rounded-lg bg-amber text-ink">
            <AudioLines className="size-5" aria-hidden="true" />
          </div>
          <div>
            <p className="text-xs text-muted">现场声学</p>
            <h1 className="text-xl font-semibold text-fg">泵声观测</h1>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex h-11 items-center gap-2 rounded-lg bg-surface px-3 text-sm text-fg shadow-panel">
            <span className={cn("size-2 rounded-full", running && !frozen ? "bg-signal live-dot" : "bg-muted")} />
            {frozen ? "已冻结" : running ? "采样中" : "待命"} · {sourceLabel}
          </span>
          <button
            type="button"
            className={cn(controlClass, !running && controlOn)}
            onClick={() => {
              if (running) engine.stop();
              else void engine.start();
            }}
          >
            {running ? <Pause className="size-4" aria-hidden="true" /> : <Play className="size-4" aria-hidden="true" />}
            {running ? "停止" : "开始观测"}
          </button>
          <button type="button" className={controlClass} disabled={!running} onClick={() => engine.toggleFreeze()}>
            {frozen ? "继续" : "冻结"}
          </button>
        </div>
      </header>
      {error ? (
        <p className="rounded-lg border-l-4 border-alarm bg-surface px-3 py-2 text-sm text-fg" role="alert">
          {error}
        </p>
      ) : null}
      <Toolbar />
      <div className="grid gap-3 lg:grid-cols-3">
        <MeterCard />
        <div className="min-w-0 lg:col-span-2">
          <SpectrumView />
        </div>
      </div>
      <WaterfallView />
      <div className="grid gap-3 lg:grid-cols-2">
        <OctaveView />
        <div className="grid min-w-0 gap-3">
          <TrendView />
          <DiagnosisCard />
        </div>
      </div>
      <SettingsPanel />
      <details className="rounded-2xl bg-surface p-4 shadow-panel">
        <summary className="text-sm font-medium text-fg">测量方法</summary>
        <div className="mt-3 space-y-2 text-sm text-muted">
          <p>
            声音在浏览器里处理，不上传。链路和开源网页声级计相同：Web Audio 的 AudioWorklet 计算时间计权，IIR
            滤波器按 IEC 61672-1 的 A/C 计权极点做双线性变换，AnalyserNode 做加 Blackman 窗的 FFT。
          </p>
          <p>
            快挡 125 ms、慢挡 1 s。等效声级是短时均方的能量平均。三分之一倍频程用 IEC 61260
            的标称中心频率，由频谱功率合成后再对齐到快挡读数。瀑布图是对数频率上的短时谱。
          </p>
          <p>
            故障线索来自公开的泵和旋转机械声学经验：叶片通过频率、转频过高、半阶次谐波、高频宽带抬升、峭度与波峰因数。演示声源是本地合成的，方便没有水泵时核对仪表。
          </p>
        </div>
      </details>
      <p className="text-xs text-muted">不能代替经检定的声级计或现场振动诊断。</p>
    </main>
  );
}
